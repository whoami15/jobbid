﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Data.SqlClient;
using libTh_LayerDTO;

namespace libTh_LayerDAO
{
    public class Truong_DAO
    {
        #region Methods

        // lay bang Truong
        public DataSet getTable_Truong(SqlConnection sqlCnn)
        {
            string strSQL = "SELECT SchoolName FROM Truong";
            SqlDataAdapter sqlDA = new SqlDataAdapter(strSQL, sqlCnn);
            DataSet ds = new DataSet();
            sqlDA.FillSchema(ds, SchemaType.Source);
            sqlDA.Fill(ds);
            sqlCnn.Close();

            return ds;
        }

        // lay bang MonHoc
        public DataSet getTable_MonHoc(SqlConnection sqlCnn)
        {
            string strSQL = "SELECT SubjectName, Theory, Practice FROM MonHoc";
            SqlDataAdapter sqlDA = new SqlDataAdapter(strSQL, sqlCnn);
            DataSet ds = new DataSet();
            sqlDA.FillSchema(ds, SchemaType.Source);
            sqlDA.Fill(ds);
            sqlCnn.Close();

            return ds;
        }

        // lay bang SinhVien
        public DataSet getTable_SinhVien(SqlConnection sqlCnn)
        {
            string strSQL = "SELECT StudentName, Sex, Birthday, Address, SubjectID, SchoolID FROM SinhVien";
            SqlDataAdapter sqlDA = new SqlDataAdapter(strSQL, sqlCnn);
            DataSet ds = new DataSet();
            sqlDA.FillSchema(ds, SchemaType.Source);
            sqlDA.Fill(ds);
            sqlCnn.Close();

            return ds;
        }

        // lay bang SinhVien_Truong
        public DataSet getTable_SinhVien_Truong(SqlConnection sqlCnn)
        {
            string strSQL = "SELECT * FROM SinhVien sv, Truong t WHERE sv.SchoolID = t.SchoolID";
            SqlDataAdapter sqlDA = new SqlDataAdapter(strSQL, sqlCnn);
            DataSet ds = new DataSet();
            sqlDA.FillSchema(ds, SchemaType.Source);
            sqlDA.Fill(ds);
            sqlCnn.Close();

            return ds;
        }

        // lay bang SinhVien_MonHoc
        public DataSet getTable_SinhVien_MonHoc(SqlConnection sqlCnn)
        {
            string strSQL = "SELECT * FROM SinhVien sv, MonHoc mh WHERE sv.SubjectID = mh.SubjectID";
            SqlDataAdapter sqlDA = new SqlDataAdapter(strSQL, sqlCnn);
            DataSet ds = new DataSet();
            sqlDA.FillSchema(ds, SchemaType.Source);
            sqlDA.Fill(ds);
            sqlCnn.Close();

            return ds;
        }

        // them Truong
        public int add_Truong(SqlConnection sqlCnn, Truong_DTO tDto)
        {
            string strSQL = "INSERT INTO Truong(SchoolName) VALUES(@SchoolName)";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@SchoolName", SqlDbType.VarChar);
            cmd.Parameters["@SchoolName"].Value = tDto.SchoolName;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi them Truong
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi them Truong
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // them MonHoc
        public int add_MonHoc(SqlConnection sqlCnn, string strSubjectName, int iTheory, int iPractice)
        {
            string strSQL = "INSERT INTO MonHoc(SubjectName, Theory, Practice) VALUES (@SubjectName, @Theory, @Practice)";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@SubjectName", SqlDbType.VarChar);
            cmd.Parameters.Add("@Theory", SqlDbType.Int);
            cmd.Parameters.Add("@Practice", SqlDbType.Int);
            cmd.Parameters["@SubjectName"].Value = strSubjectName;
            cmd.Parameters["@Theory"].Value = iTheory;
            cmd.Parameters["@Practice"].Value = iPractice;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi them MonHoc
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi them MonHoc
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // them SinhVien
        public int add_SinhVien(SqlConnection sqlCnn, string strStudentName, bool bSex, DateTime dtBirthday, string strAddress, int iSubjectID, int iSchoolID)
        {
            string strSQL = "INSERT INTO SinhVien(StudentName, Sex, Birthday, Address, SubjectID, SchoolID) VALUES (@StudentName, @Sex, @Birthday, @Address, @SubjectID, @SchoolID)";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@StudentName", SqlDbType.VarChar);
            cmd.Parameters.Add("@Sex", SqlDbType.Bit);
            cmd.Parameters.Add("@Birthday", SqlDbType.DateTime);
            cmd.Parameters.Add("@Address", SqlDbType.VarChar);
            cmd.Parameters.Add("@SubjectID", SqlDbType.Int);
            cmd.Parameters.Add("@SchoolID", SqlDbType.Int);
            cmd.Parameters["@StudentName"].Value = strStudentName;
            cmd.Parameters["@Sex"].Value = bSex;
            cmd.Parameters["@Birthday"].Value = dtBirthday;
            cmd.Parameters["@Address"].Value = strAddress;
            cmd.Parameters["@SubjectID"].Value = iSubjectID;
            cmd.Parameters["@SchoolID"].Value = iSchoolID;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi them SinhVien
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi them SinhVien
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // xoa Truong
        public int delete_Truong(SqlConnection sqlCnn, Truong_DTO tDto)
        {
            string strSQL = "DELETE FROM Truong WHERE SchoolID = @SchoolID";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@SchoolID", SqlDbType.Int);
            cmd.Parameters["@SchoolID"].Value = tDto.SchoolID;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi xoa Truong
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi xoa Truong
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // xoa MonHoc
        public int delete_MonHoc(SqlConnection sqlCnn, int iSubjectID)
        {
            string strSQL = "DELETE FROM MonHoc WHERE SubjectID = @SubjectID";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@SubjectID", SqlDbType.Int);
            cmd.Parameters["@SubjectID"].Value = iSubjectID;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi xoa MonHoc
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi xoa MonHoc
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // xoa SinhVien
        public int delete_SinhVien(SqlConnection sqlCnn, int iMssv)
        {
            string strSQL = "DELETE FROM SinhVien WHERE Mssv = @Mssv";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@Mssv", SqlDbType.Int);
            cmd.Parameters["@Mssv"].Value = iMssv;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi xoa SinhVien
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi xoa SinhVien
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // sua Truong
        public int update_Truong(SqlConnection sqlCnn, Truong_DTO tDto)
        {
            string strSQL = "UPDATE Truong SET SchoolName = @SchoolName WHERE SchoolID = @SchoolID";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@SchoolName", SqlDbType.VarChar);
            cmd.Parameters.Add("@SchoolID", SqlDbType.Int);
            cmd.Parameters["@SchoolName"].Value = tDto.SchoolName;
            cmd.Parameters["@SchoolID"].Value = tDto.SchoolID;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi sua Truong
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi sua Truong
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // sua MonHoc
        public int update_MonHoc(SqlConnection sqlCnn, int iSubjectID, string strSubjectName, int iTheory, int iPractice)
        {
            string strSQL = "UPDATE MonHoc SET SubjectName = @SubjectName, Theory = @Theory, Practice = @Practice WHERE SubjectID = @SubjectID";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@SubjectName", SqlDbType.VarChar);
            cmd.Parameters.Add("@Theory", SqlDbType.Int);
            cmd.Parameters.Add("@Practice", SqlDbType.Int);
            cmd.Parameters.Add("@SubjectID", SqlDbType.Int);
            cmd.Parameters["@SubjectName"].Value = strSubjectName;
            cmd.Parameters["@Theory"].Value = iTheory;
            cmd.Parameters["@Practice"].Value = iPractice;
            cmd.Parameters["@SubjectID"].Value = iSubjectID;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi sua MonHoc
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi sua MonHoc
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        // sua SinhVien
        public int update_SinhVien(SqlConnection sqlCnn, int iMssv, string strStudentName, bool bSex, DateTime dtBirthday, string strAddress, int iSubjectID, int iSchoolID)
        {
            string strSQL = "UPDATE SinhVien SET StudentName = @StudentName, Sex = @Sex, Birthday = @Birthday, Address = @Address, SubjectID = @SubjectID, SchoolID = @SchoolID WHERE Mssv = @Mssv";
            SqlCommand cmd = new SqlCommand(strSQL, sqlCnn);
            cmd.Parameters.Add("@StudentName", SqlDbType.VarChar);
            cmd.Parameters.Add("@Sex", SqlDbType.Bit);
            cmd.Parameters.Add("@Birthday", SqlDbType.DateTime);
            cmd.Parameters.Add("@Address", SqlDbType.VarChar);
            cmd.Parameters.Add("@SubjectID", SqlDbType.Int);
            cmd.Parameters.Add("@SchoolID", SqlDbType.Int);
            cmd.Parameters.Add("@Mssv", SqlDbType.Int);
            cmd.Parameters["@StudentName"].Value = strStudentName;
            cmd.Parameters["@Sex"].Value = bSex;
            cmd.Parameters["@Birthday"].Value = dtBirthday;
            cmd.Parameters["@Address"].Value = strAddress;
            cmd.Parameters["@SubjectID"].Value = iSubjectID;
            cmd.Parameters["@SchoolID"].Value = iSchoolID;
            cmd.Parameters["@Mssv"].Value = iMssv;

            int iRow = 0;
            try
            {
                iRow = cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                // thong bao loi sua SinhVien
            }
            finally
            {
                sqlCnn.Close();
            }

            if (iRow == 0)
            {
                // thong bao loi sua SinhVien
            }
            else
            {
                // thanh cong
            }

            return iRow;
        }

        #endregion Methods

    }
}
