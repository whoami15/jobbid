﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using libTh_LayerBUS;
using libTh_LayerBUS.localhostBUS;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{
    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod]
    public DataSet getTable_Truong()
    {
        Truong_BUS tBus = new Truong_BUS();
        DataSet ds = tBus.getTable_Truong();

        return ds;
    }

    [WebMethod]
    public DataSet getTable_SinhVien_Truong()
    {
        Truong_BUS tBus = new Truong_BUS();
        DataSet ds = tBus.getTable_SinhVien_Truong();

        return ds;
    }

    [WebMethod]
    public int add_Truong(Truong_DTO tDto)
    {
        Truong_BUS tBus = new Truong_BUS();
        int iRow = tBus.add_Truong(tDto);

        return iRow;
    }

    [WebMethod]
    public int delete_Truong(Truong_DTO tDto)
    {
        Truong_BUS tBus = new Truong_BUS();
        int iRow = tBus.delete_Truong(tDto);

        return iRow;
    }

    [WebMethod]
    public int update_Truong(Truong_DTO tDto)
    {
        Truong_BUS tBus = new Truong_BUS();
        int iRow = tBus.update_Truong(tDto);

        return iRow;
    }
    
}
