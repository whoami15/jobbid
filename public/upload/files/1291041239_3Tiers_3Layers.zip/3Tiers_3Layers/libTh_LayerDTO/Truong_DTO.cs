﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace libTh_LayerDTO
{
    public class Truong_DTO
    {
        #region Attributes

        private int iSchoolID;
        private string strSchoolName;

        #endregion Attributes

        #region Properties

        public int SchoolID
        {
            set { iSchoolID = value; }
            get { return iSchoolID; }
        }

        public string SchoolName
        {
            set { strSchoolName = value; }
            get { return strSchoolName; }
        }

        #endregion Properties

        #region Methods

        public Truong_DTO()
        {
            this.iSchoolID = 0;
            this.strSchoolName = "";
        }

        #endregion Methods

    }
}
