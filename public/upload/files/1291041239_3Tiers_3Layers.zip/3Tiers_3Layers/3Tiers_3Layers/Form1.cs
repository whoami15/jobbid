﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;
using libTh_LayerBUS;
using _3Tiers_3Layers.localhostGUI;

namespace _3Tiers_3Layers
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnXL_Them_Click(object sender, EventArgs e)
        {
            if (txtTh_TenTruong.Text != "")
            {
                Truong_DTO tDto = new Truong_DTO();
                tDto.SchoolName = txtTh_TenTruong.Text;

                Service gui = new Service();
                int iRow = gui.add_Truong(tDto);

                if (iRow == 0)
                    MessageBox.Show("Thêm trường bị lỗi", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                    MessageBox.Show("Thêm trường thành công", "Thông báo");
            }
            else
                MessageBox.Show("Dữ liệu nhập rỗng","Lỗi");
        }

    }
}
