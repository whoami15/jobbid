﻿namespace _3Tiers_3Layers
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.txtTh_TenTruong = new System.Windows.Forms.TextBox();
            this.btnXL_Them = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(62, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Tên trường:";
            // 
            // txtTh_TenTruong
            // 
            this.txtTh_TenTruong.Location = new System.Drawing.Point(79, 34);
            this.txtTh_TenTruong.Name = "txtTh_TenTruong";
            this.txtTh_TenTruong.Size = new System.Drawing.Size(178, 20);
            this.txtTh_TenTruong.TabIndex = 1;
            // 
            // btnXL_Them
            // 
            this.btnXL_Them.Location = new System.Drawing.Point(108, 73);
            this.btnXL_Them.Name = "btnXL_Them";
            this.btnXL_Them.Size = new System.Drawing.Size(64, 33);
            this.btnXL_Them.TabIndex = 2;
            this.btnXL_Them.Text = "Thêm";
            this.btnXL_Them.UseVisualStyleBackColor = true;
            this.btnXL_Them.Click += new System.EventHandler(this.btnXL_Them_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 192);
            this.Controls.Add(this.btnXL_Them);
            this.Controls.Add(this.txtTh_TenTruong);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Demo 3Tiers-3Layers";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        internal System.Windows.Forms.TextBox txtTh_TenTruong;
        internal System.Windows.Forms.Button btnXL_Them;
    }
}

