﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.WebControls;
using libTh_LayerDAO;
using libTh_LayerDTO;

[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class Service : System.Web.Services.WebService
{
    public Service () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    private SqlConnection ConnectionData()
    {
        string strCnn = ConfigurationManager.ConnectionStrings["Student_Data"].ToString();
        SqlConnection sqlCnn = new SqlConnection(strCnn);
        sqlCnn.Open();

        return sqlCnn;
    }

    [WebMethod]
    public DataSet getTable_Truong()
    {
        SqlConnection sqlCnn = this.ConnectionData();
        Truong_DAO tDao = new Truong_DAO();
        DataSet ds = tDao.getTable_Truong(sqlCnn);

        return ds;
    }

    [WebMethod]
    public DataSet getTable_SinhVien_Truong()
    {
        SqlConnection sqlCnn = this.ConnectionData();
        libTh_LayerDAO.Truong_DAO tDao = new libTh_LayerDAO.Truong_DAO();
        DataSet ds = tDao.getTable_SinhVien_Truong(sqlCnn);

        return ds;
    }

    [WebMethod]
    public int add_Truong(Truong_DTO tDto)
    {
        SqlConnection sqlCnn = this.ConnectionData();
        Truong_DAO tDao = new Truong_DAO();
        int iRow = tDao.add_Truong(sqlCnn, tDto);

        return iRow;
    }

    [WebMethod]
    public int delete_Truong(libTh_LayerDTO.Truong_DTO tDto)
    {
        SqlConnection sqlCnn = this.ConnectionData();
        libTh_LayerDAO.Truong_DAO tDao = new libTh_LayerDAO.Truong_DAO();
        int iRow = tDao.delete_Truong(sqlCnn, tDto);

        return iRow;
    }

    [WebMethod]
    public int update_Truong(libTh_LayerDTO.Truong_DTO tDto)
    {
        SqlConnection sqlCnn = this.ConnectionData();
        libTh_LayerDAO.Truong_DAO tDao = new libTh_LayerDAO.Truong_DAO();
        int iRow = tDao.update_Truong(sqlCnn, tDto);

        return iRow;
    }
    
}
