﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using libTh_LayerBUS.localhostBUS;

namespace libTh_LayerBUS
{
    public class Truong_BUS
    {
        #region Methods

        // lay bang Truong
        public DataSet getTable_Truong()
        {
            DataSet ds = new DataSet();
            try
            {
                Service client = new Service();
                ds = client.getTable_Truong();

            }
            catch (Exception ex)
            {
            }

            return ds;
        }

        // lay bang SinhVien_Truong
        public DataSet getTable_SinhVien_Truong()
        {
            DataSet ds = new DataSet();
            try
            {
                Service client = new Service();
                ds = client.getTable_SinhVien_Truong();
            }
            catch (Exception ex)
            {
            }

            return ds;
        }

        // them Truong
        public int add_Truong(Truong_DTO tDto)
        {
            int iRow = 0;
            try
            {
                Service client = new Service();
                iRow = client.add_Truong(tDto);
            }
            catch (Exception ex)
            {
            }

            return iRow;
        }

        // xoa Truong
        public int delete_Truong(Truong_DTO tDto)
        {
            int iRow = 0;
            try
            {
                Service client = new Service();
                iRow = client.delete_Truong(tDto);
            }
            catch (Exception ex)
            {
            }

            return iRow;
        }

        // sua Truong
        public int update_Truong(Truong_DTO tDto)
        {
            int iRow = 0;
            try
            {
                Service client = new Service();
                iRow = client.update_Truong(tDto);
            }
            catch (Exception ex)
            {
            }

            return iRow;
        }

        #endregion Methods

    }
}
