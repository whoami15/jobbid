using System;
using System.Data;
using System.Data.OleDb;
using System.Collections;

namespace QLHS3
{
	/// <summary>
	/// Summary description for LopData.
	/// </summary>
	public class LopDataAccess
	{
		private DataProvider _provider = new DataProvider();
		
		public LopDataAccess()
		{
			_provider.connect();
		}

        public ArrayList getDsLop()
		{
			string query = "SELECT * FROM LOP";
            OleDbDataReader reader = (OleDbDataReader)_provider.executeQuery(query);
            
            ArrayList arr = new ArrayList();
            LopInfo     lop;
            while (reader.Read())
            {
                lop = new LopInfo();
                lop.MaLop = reader["MaLop"].ToString();
                lop.TenLop = reader["TenLop"].ToString();
                lop.SiSo = int.Parse(reader["SiSo"].ToString());

                arr.Add(lop);
            }

            reader.Close();
            return arr;
		}
	}
}
