using System;

namespace QLHS3
{
	/// <summary>
	/// Summary description for HocSinhCtl.
	/// </summary>
	public class HocSinhControl
	{
		private HocSinhDataAccess data = new HocSinhDataAccess();

		public void insert(HocSinhInfo info)
		{
			data.insert(info);
		}

        public void delete(HocSinhInfo info)
		{
			data.delete(info);
		}

        public void update(HocSinhInfo info)
		{
			data.update(info);
		}

        public void tinhDTB(HocSinhInfo info)
		{
			info.DTB = ( info.Toan + info.Ly + info.Hoa ) / 3;
		}

	}
}
