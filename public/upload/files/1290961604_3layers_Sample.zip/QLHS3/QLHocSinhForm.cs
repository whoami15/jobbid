﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;

namespace QLHS3
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class Form1 : System.Windows.Forms.Form
	{
		private System.Windows.Forms.ComboBox cmbLop;
		private System.Windows.Forms.DateTimePicker dtpNgaySinh;
		private System.Windows.Forms.TextBox txtHoa;
		private System.Windows.Forms.TextBox txtLy;
		private System.Windows.Forms.TextBox txtToan;
		private System.Windows.Forms.Label label10;
		private System.Windows.Forms.Label label9;
		private System.Windows.Forms.TextBox txtDiaChi;
		private System.Windows.Forms.TextBox txtTenHS;
		private System.Windows.Forms.TextBox txtMaHS;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnDong;
		private System.Windows.Forms.Button btnXoa;
		private System.Windows.Forms.Button btnThem;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.GroupBox groupBox2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.GroupBox groupBox1;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public Form1()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.cmbLop = new System.Windows.Forms.ComboBox();
			this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
			this.txtHoa = new System.Windows.Forms.TextBox();
			this.txtLy = new System.Windows.Forms.TextBox();
			this.txtToan = new System.Windows.Forms.TextBox();
			this.label10 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.txtDiaChi = new System.Windows.Forms.TextBox();
			this.txtTenHS = new System.Windows.Forms.TextBox();
			this.txtMaHS = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.btnDong = new System.Windows.Forms.Button();
			this.btnXoa = new System.Windows.Forms.Button();
			this.btnThem = new System.Windows.Forms.Button();
			this.label2 = new System.Windows.Forms.Label();
			this.groupBox2 = new System.Windows.Forms.GroupBox();
			this.label1 = new System.Windows.Forms.Label();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.groupBox2.SuspendLayout();
			this.SuspendLayout();
			// 
			// cmbLop
			// 
			this.cmbLop.Location = new System.Drawing.Point(142, 251);
			this.cmbLop.Name = "cmbLop";
			this.cmbLop.Size = new System.Drawing.Size(144, 21);
			this.cmbLop.TabIndex = 43;
			// 
			// dtpNgaySinh
			// 
			this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Short;
			this.dtpNgaySinh.Location = new System.Drawing.Point(142, 171);
			this.dtpNgaySinh.Name = "dtpNgaySinh";
			this.dtpNgaySinh.Size = new System.Drawing.Size(144, 20);
			this.dtpNgaySinh.TabIndex = 42;
			// 
			// txtHoa
			// 
			this.txtHoa.Location = new System.Drawing.Point(470, 291);
			this.txtHoa.Name = "txtHoa";
			this.txtHoa.Size = new System.Drawing.Size(80, 20);
			this.txtHoa.TabIndex = 41;
			this.txtHoa.Text = "0";
			// 
			// txtLy
			// 
			this.txtLy.Location = new System.Drawing.Point(286, 291);
			this.txtLy.Name = "txtLy";
			this.txtLy.Size = new System.Drawing.Size(80, 20);
			this.txtLy.TabIndex = 40;
			this.txtLy.Text = "0";
			// 
			// txtToan
			// 
			this.txtToan.Location = new System.Drawing.Point(102, 291);
			this.txtToan.Name = "txtToan";
			this.txtToan.Size = new System.Drawing.Size(80, 20);
			this.txtToan.TabIndex = 39;
			this.txtToan.Text = "0";
			// 
			// label10
			// 
			this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label10.Location = new System.Drawing.Point(398, 291);
			this.label10.Name = "label10";
			this.label10.Size = new System.Drawing.Size(72, 23);
			this.label10.TabIndex = 38;
			this.label10.Text = "Hóa";
			// 
			// label9
			// 
			this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label9.Location = new System.Drawing.Point(214, 291);
			this.label9.Name = "label9";
			this.label9.Size = new System.Drawing.Size(72, 23);
			this.label9.TabIndex = 37;
			this.label9.Text = "Lý";
			// 
			// txtDiaChi
			// 
			this.txtDiaChi.Location = new System.Drawing.Point(142, 211);
			this.txtDiaChi.Name = "txtDiaChi";
			this.txtDiaChi.Size = new System.Drawing.Size(416, 20);
			this.txtDiaChi.TabIndex = 36;
			this.txtDiaChi.Text = "";
			// 
			// txtTenHS
			// 
			this.txtTenHS.Location = new System.Drawing.Point(142, 131);
			this.txtTenHS.Name = "txtTenHS";
			this.txtTenHS.Size = new System.Drawing.Size(416, 20);
			this.txtTenHS.TabIndex = 35;
			this.txtTenHS.Text = "";
			// 
			// txtMaHS
			// 
			this.txtMaHS.Location = new System.Drawing.Point(142, 91);
			this.txtMaHS.Name = "txtMaHS";
			this.txtMaHS.Size = new System.Drawing.Size(416, 20);
			this.txtMaHS.TabIndex = 34;
			this.txtMaHS.Text = "";
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label8.Location = new System.Drawing.Point(30, 291);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(72, 23);
			this.label8.TabIndex = 33;
			this.label8.Text = "Toán";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label7.Location = new System.Drawing.Point(30, 251);
			this.label7.Name = "label7";
			this.label7.TabIndex = 32;
			this.label7.Text = "Lớp";
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label6.Location = new System.Drawing.Point(30, 211);
			this.label6.Name = "label6";
			this.label6.TabIndex = 31;
			this.label6.Text = "Địa chỉ";
			// 
			// label5
			// 
			this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label5.Location = new System.Drawing.Point(30, 171);
			this.label5.Name = "label5";
			this.label5.TabIndex = 30;
			this.label5.Text = "Ngày sinh";
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label4.Location = new System.Drawing.Point(30, 131);
			this.label4.Name = "label4";
			this.label4.TabIndex = 29;
			this.label4.Text = "Tên học sinh";
			// 
			// label3
			// 
			this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label3.Location = new System.Drawing.Point(30, 91);
			this.label3.Name = "label3";
			this.label3.TabIndex = 28;
			this.label3.Text = "Mã học sinh";
			// 
			// btnDong
			// 
			this.btnDong.Location = new System.Drawing.Point(494, 355);
			this.btnDong.Name = "btnDong";
			this.btnDong.TabIndex = 27;
			this.btnDong.Text = "Đóng";
			this.btnDong.Click += new System.EventHandler(this.btnDong_Click);
			// 
			// btnXoa
			// 
			this.btnXoa.Location = new System.Drawing.Point(118, 355);
			this.btnXoa.Name = "btnXoa";
			this.btnXoa.TabIndex = 26;
			this.btnXoa.Text = "Xóa";
			this.btnXoa.Click += new System.EventHandler(this.btnXoa_Click);
			// 
			// btnThem
			// 
			this.btnThem.Location = new System.Drawing.Point(22, 355);
			this.btnThem.Name = "btnThem";
			this.btnThem.TabIndex = 25;
			this.btnThem.Text = "Thêm";
			this.btnThem.Click += new System.EventHandler(this.btnThem_Click);
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.label2.Location = new System.Drawing.Point(142, 11);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(312, 32);
			this.label2.TabIndex = 24;
			this.label2.Text = "Thông tin học sinh";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// groupBox2
			// 
			this.groupBox2.BackColor = System.Drawing.SystemColors.ControlText;
			this.groupBox2.Controls.Add(this.label1);
			this.groupBox2.Location = new System.Drawing.Point(14, 331);
			this.groupBox2.Name = "groupBox2";
			this.groupBox2.Size = new System.Drawing.Size(560, 8);
			this.groupBox2.TabIndex = 23;
			this.groupBox2.TabStop = false;
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(3, 16);
			this.label1.Name = "label1";
			this.label1.TabIndex = 0;
			this.label1.Text = "label1";
			// 
			// groupBox1
			// 
			this.groupBox1.BackColor = System.Drawing.SystemColors.ControlText;
			this.groupBox1.Location = new System.Drawing.Point(14, 59);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(560, 8);
			this.groupBox1.TabIndex = 22;
			this.groupBox1.TabStop = false;
			// 
			// Form1
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(588, 389);
			this.Controls.Add(this.cmbLop);
			this.Controls.Add(this.dtpNgaySinh);
			this.Controls.Add(this.txtHoa);
			this.Controls.Add(this.txtLy);
			this.Controls.Add(this.txtToan);
			this.Controls.Add(this.label10);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.txtDiaChi);
			this.Controls.Add(this.txtTenHS);
			this.Controls.Add(this.txtMaHS);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.label6);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.btnDong);
			this.Controls.Add(this.btnXoa);
			this.Controls.Add(this.btnThem);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.groupBox2);
			this.Controls.Add(this.groupBox1);
			this.Name = "Form1";
			this.Text = "Form1";
			this.Load += new System.EventHandler(this.Form1_Load);
			this.groupBox2.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new Form1());
		}

		/// Tao doi tuong control de thuc hien xu ly nghiep vu.
		HocSinhControl hsControl;
		LopControl lopControl;

		/// Danh sach lop
		ArrayList dsLop;

		private void btnThem_Click(object sender, System.EventArgs e)
		{
			HocSinhInfo hs = new HocSinhInfo();

			// Lay thong tin hoc sinh tu form vao doi tuong hocsinh
			LayThongTinHS(ref hs);

			// Tinh diem trung binh va cap nhat du lieu
			hsControl.tinhDTB(hs);
			hsControl.insert(hs);

			MessageBox.Show("Them du lieu thanh cong");
		}

		private void Form1_Load(object sender, System.EventArgs e)
		{
			string DBFullPathName = Application.StartupPath + "\\HOCSINH.mdb";
			DataProvider.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + DBFullPathName;

			hsControl = new HocSinhControl();
			lopControl = new LopControl();

			// Lay danh sach lop
			dsLop = lopControl.getDsLop();
			
			// ket danh sach lop voi combo box de the hien
			cmbLop.DisplayMember = "TenLop";
			cmbLop.ValueMember = "MaLop";
			cmbLop.DataSource = dsLop;
		}

		private void LayThongTinHS (ref HocSinhInfo hs)
		{
			hs.MaHS = txtMaHS.Text;
			hs.DiaChi = txtDiaChi.Text;
			hs.TenHS = txtTenHS.Text;
			hs.MaLop = cmbLop.SelectedValue.ToString();
			hs.NgaySinh = dtpNgaySinh.Value;
			if (txtToan.Text == "") 
				hs.Toan = int.Parse(txtToan.Text);
			else 
				hs.Toan = 0;

			if (txtLy.Text == "") 
				hs.Ly = int.Parse(txtLy.Text);
			else 
				hs.Ly = 0;

			if (txtHoa.Text == "") 
				hs.Hoa = int.Parse(txtHoa.Text);
			else 
				hs.Hoa = 0;			
		}

		private void btnXoa_Click(object sender, System.EventArgs e)
		{
			HocSinhInfo hs = new HocSinhInfo();

			// Lay thong tin hoc sinh tu form vao doi tuong hocsinh
			LayThongTinHS(ref hs);

			// Xoa doi tuong khoi co so du lieu
			hsControl.delete(hs);

			MessageBox.Show("Xoa du lieu thanh cong");
		}

		private void btnDong_Click(object sender, System.EventArgs e)
		{
			this.Close();
		}
	}
}
