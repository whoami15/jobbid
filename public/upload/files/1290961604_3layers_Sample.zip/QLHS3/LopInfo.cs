using System;

namespace QLHS3
{
	/// <summary>
	/// Summary description for LopInfo.
	/// </summary>
	public class LopInfo
	{
		private string _maLop;
		private string _tenLop;
		private int _siso;

		public string MaLop
		{
			get{return _maLop;}
			set {_maLop = value;}
		}

		public string TenLop
		{
			get{return _tenLop;}
			set {_tenLop = value;}
		}

		public int SiSo
		{
			get{return _siso;}
			set {_siso = value;}
		}
	}


}
