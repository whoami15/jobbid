using System;
using System.Data.OleDb;
using System.Data;

namespace QLHS3
{
	/// <summary>
	/// Summary description for DataProvider.
	/// </summary>
	public class DataProvider
	{
		protected static string _connectionString;

		protected OleDbConnection connection;
		protected OleDbDataAdapter adapter;
		protected OleDbCommand command;


		public static string ConnectionString
		{
			get
			{
				return _connectionString;
			}
			set
			{
				_connectionString = value;
			}
		}

		public void connect()
		{
			connection = new OleDbConnection(ConnectionString);
			connection.Open();
		}

		public void disconnect()
		{
			connection.Close();
		}

		public IDataReader executeQuery(string sqlString)
		{			
			command = new OleDbCommand(sqlString, connection);
			return command.ExecuteReader();			
		}

/*        public DataTable executeQuery(string sqlString)
        {
            DataSet ds = new DataSet();
            adapter = new OleDbDataAdapter(sqlString, connection);
            adapter.Fill(ds);
            return ds.Tables[0];
        }
*/
		public void executeNonQuery(string sqlString)
		{
			command = new OleDbCommand(sqlString, connection);
			command.ExecuteNonQuery();
		}

		public object executeScalar(string sqlString)
		{
			command = new OleDbCommand(sqlString, connection);
			return command.ExecuteScalar();
		}

	}
}
