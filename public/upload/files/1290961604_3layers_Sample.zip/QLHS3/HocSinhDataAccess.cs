using System;

namespace QLHS3
{
	/// <summary>
	/// Summary description for HocSinhData.
	/// </summary>
	public class HocSinhDataAccess
	{
		private DataProvider _provider = new DataProvider();
	
		public HocSinhDataAccess()
		{
			_provider.connect();
		}

		public void insert(HocSinhInfo info)
		{
			string insertCommand = "INSERT INTO HOCSINH VALUES('" + 
				info.MaHS + "', '" +
				info.TenHS + "', '" + info.NgaySinh.ToShortDateString() + "', '" +
				info.DiaChi + "', " +
				info.DTB + ", '" +
				info.MaLop + "')";

			_provider.executeNonQuery(insertCommand);
		}

        public void update(HocSinhInfo info)
		{
			string updateCommand = "UPDATE HOCSINH " +
									"SET TenHS = '" + info.TenHS + "', " +
									" NgaySinh = '" + info.NgaySinh.ToShortDateString() + "', " +
									" DiaChi = '" + info.DiaChi + "', " +
									" DTB = " + info.DTB + ", " +
									" MaLop = '" + info.MaLop + "' " +
									" WHERE MaHS = '" + info.MaHS + "'";

			_provider.executeNonQuery(updateCommand);
		}

		public void delete(HocSinhInfo info)
		{
			string deleteCommand = "DELETE FROM HOCSINH WHERE MaHS = '" + info.MaHS+"'";
			_provider.executeNonQuery(deleteCommand);
		}


	}
}
