using System;
using System.Collections;
using System.Data.OleDb;

namespace QLHS3
{
	/// <summary>
	/// Summary description for LopControl
	/// </summary>
	public class LopControl
	{
		private LopDataAccess dataAccess = new LopDataAccess();

		public ArrayList getDsLop()
		{
            return dataAccess.getDsLop();
		}
	}
}
