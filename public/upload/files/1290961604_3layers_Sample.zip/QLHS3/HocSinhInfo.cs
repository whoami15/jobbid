using System;

namespace QLHS3
{
	/// <summary>
	/// Summary description for HocSinhInfo.
	/// </summary>
	public class HocSinhInfo
	{
		private string _maHS;
		private string _tenHS;
		private string _diachi;
		private DateTime _ngaysinh;
		private double _dtb;
		private string _maLop;
		private double _toan;
		private double _ly;
		private double _hoa;

		public string MaHS
		{
			get{return _maHS;}
			set
			{
				if (value == null)
					throw new Exception("Ma HS khong duoc rong");
				_maHS = value;
			}
		}
		
		public string TenHS
		{
			get{return _tenHS;}
			set{_tenHS = value;}
		}

		public DateTime NgaySinh
		{
			get{return _ngaysinh;}
			set{_ngaysinh = value;}
		}

		public string DiaChi
		{
			get{return _diachi;}
			set{_diachi = value;}
		}

		public double DTB
		{
			get{return _dtb;}
			set
			{
				if (value < 0 || value >10) 
					throw new Exception("Diem trung binh phai lon hon 0 va nho hon 10");
				_dtb = value;
			}
		}
	
		public string MaLop
		{
			get{return _maLop;}
			set{_maLop = value;}
		}

		public double Toan
		{
			get{return _toan;}
			set
			{
				if (value < 0 || value >10) 
					throw new Exception("Diem Toan phai lon hon 0 va nho hon 10");
				_toan = value;
			}
		}

		public double Ly
		{
			get{return _ly;}
			set
			{
				if (value < 0 || value >10) 
					throw new Exception("Diem Ly phai lon hon 0 va nho hon 10");
				_ly = value;
			}
		}

		public double Hoa
		{
			get{return _hoa;}
			set
			{
				if (value < 0 || value >10) 
					throw new Exception("Diem Hoa phai lon hon 0 va nho hon 10");
				_hoa = value;
			}
		}
	}
}
