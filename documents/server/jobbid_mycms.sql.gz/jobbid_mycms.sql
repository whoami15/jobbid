-- phpMyAdmin SQL Dump
-- version 3.3.8
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Dec 28, 2010 at 12:03 AM
-- Server version: 5.0.91
-- PHP Version: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `jobbid_mycms`
--

-- --------------------------------------------------------

--
-- Table structure for table `accounts`
--

CREATE TABLE IF NOT EXISTS `accounts` (
  `id` bigint(20) NOT NULL auto_increment,
  `username` varchar(255) default NULL,
  `password` varchar(255) default NULL,
  `sodienthoai` varchar(20) default NULL,
  `lastlogin` datetime default NULL,
  `timeonline` bigint(20) default NULL,
  `role` int(11) default NULL,
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=36 ;

--
-- Dumping data for table `accounts`
--

INSERT INTO `accounts` (`id`, `username`, `password`, `sodienthoai`, `lastlogin`, `timeonline`, `role`, `active`) VALUES
(1, 'admin@jobbid.com', 'e10adc3949ba59abbe56e057f20f883e', '123456789', '2010-12-27 22:05:43', NULL, 1, 1),
(33, 'duy_ngu2003@yahoo.com', 'e10adc3949ba59abbe56e057f20f883e', '0905267932', '2010-12-27 22:13:06', 0, 1, 1),
(34, 'nclong87@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '0973862100', '2010-12-27 22:04:39', 0, 2, 1),
(35, 'mytrang6789@gmail.com', 'e10adc3949ba59abbe56e057f20f883e', '0979932151', '2010-12-27 23:52:35', 0, 2, 1);

-- --------------------------------------------------------

--
-- Table structure for table `activecodes`
--

CREATE TABLE IF NOT EXISTS `activecodes` (
  `id` bigint(20) NOT NULL auto_increment,
  `account_id` bigint(20) default NULL,
  `active_code` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_activecodes_accounts` (`account_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=20 ;

--
-- Dumping data for table `activecodes`
--

INSERT INTO `activecodes` (`id`, `account_id`, `active_code`) VALUES
(17, 33, 'wi4whcewn9');

-- --------------------------------------------------------

--
-- Table structure for table `articles`
--

CREATE TABLE IF NOT EXISTS `articles` (
  `id` bigint(20) NOT NULL auto_increment,
  `alias` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `imagedes` varchar(255) default NULL,
  `contentdes` text,
  `content` text,
  `datemodified` datetime default NULL,
  `usermodified` varchar(100) default NULL,
  `viewcount` int(11) default NULL,
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `articles`
--

INSERT INTO `articles` (`id`, `alias`, `title`, `imagedes`, `contentdes`, `content`, `datemodified`, `usermodified`, `viewcount`, `active`) VALUES
(2, 'lo-dien-2-nu-sinh-danh-ban-bat-quy-thap-vincom', 'Lộ diện 2 nữ sinh đánh bạn, bắt quỳ  tháp Vincom', 'http://localhost/mycms/images/upload/1287644796_2[3].jpg', 'Một ngày sau khi clip nữ sinh đánh bạn, bắt quỳ được tung lên mạng, Công an quận Hai Bà Trưng (Hà Nội) đã xác định 3 nhân vật liên quan là học sinh THCS Vân Hồ và THCS Nguyễn Phong Sắc.', '<p class="Lead">Một ng&agrave;y sau khi clip nữ sinh đ&aacute;nh bạn, bắt quỳ được  tung l&ecirc;n mạng, C&ocirc;ng an quận Hai B&agrave; Trưng (H&agrave; Nội) đ&atilde; x&aacute;c định 3 nh&acirc;n vật  li&ecirc;n quan l&agrave; học sinh THCS V&acirc;n Hồ v&agrave; THCS Nguyễn Phong Sắc.<br />&gt; <a class="Lead" href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21810/">X&ocirc;n xao clip nữ sinh đ&aacute;nh bạn, bắt quỳ</a></p>\n<p class="Normal">Trao đổi với <em>VnExpress</em>, &ocirc;ng Nguyễn Như Thắng,  Trưởng ph&ograve;ng GD&amp;ĐT quận Hai B&agrave; Trưng cho biết, sau khi c&oacute; sự chỉ  đạo của Sở Gi&aacute;o dục, ph&ograve;ng đ&atilde; c&ugrave;ng trường THCS V&acirc;n Hồ phối hợp với c&ocirc;ng  an quận l&agrave;m r&otilde; vụ việc.</p>\n<p class="Normal">Danh t&iacute;nh những nh&acirc;n vật trong clip đ&atilde; được x&aacute;c định.  Nạn nh&acirc;n l&agrave; học sinh lớp 8 THCS V&acirc;n Hồ, hai nữ sinh đ&aacute;nh bạn học lớp 8  v&agrave; lớp 9 THCS Nguyễn Phong Sắc. Quay clip l&agrave; hai nam sinh lớp 10 THPT  D&acirc;n lập Đinh Ti&ecirc;n Ho&agrave;ng. Địa điểm xảy ra vụ đ&aacute;nh nhau được x&aacute;c định l&agrave;  tại cầu thang bộ của to&agrave; nh&agrave; Vincom 2.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/18/B8/2%5B3%5D.jpg" border="1" alt="" width="480" height="350" /></td>\n</tr>\n<tr>\n<td class="Image">Nữ sinh đồng &yacute; giải quyết m&acirc;u thuẫn bằng nắm đấm. <em>Ảnh chụp từ clip.</em></td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Theo lời khai của những người li&ecirc;n quan, chiều 30/9  hai nữ sinh trường Nguyễn Phong Sắc đi học về, đến Trung t&acirc;m thương mại  Vincom th&igrave; gặp nữ sinh trường THCS V&acirc;n Hồ (trường Nguyễn Phong Sắc đang  học nhờ cơ sở của trường V&acirc;n Hồ). Do m&acirc;u thuẫn trước đ&oacute; n&ecirc;n c&aacute;c nữ sinh  đ&atilde; dẫn nhau đến cầu thang bộ trung t&acirc;m thương mại Vincom 2 để giải  quyết.</p>\n<p class="Normal">Hai học sinh lớp 10 l&agrave; bạn của hai nữ sinh trường  Nguyễn Phong Sắc biết chuyện, đ&atilde; rủ nhau v&agrave;o xem, d&ugrave;ng điện thoại để  quay lại to&agrave;n bộ sự việc. Ng&agrave;y 10/10, ch&iacute;nh cậu học tr&ograve; tr&ecirc;n đ&atilde; nhờ bạn  tung clip l&ecirc;n mạng.</p>\n<p class="Normal">Clip xuất hiện tr&ecirc;n trang Youtube ng&agrave;y 10/10 với thời  lượng hơn 3 ph&uacute;t đ&atilde; g&acirc;y x&ocirc;n xao dư luận. Ba nh&acirc;n vật ch&iacute;nh trong clip  đều mặc đồng phục học sinh, trong đ&oacute; nạn nh&acirc;n li&ecirc;n tục bị hai nữ sinh  k&eacute;o t&oacute;c, t&aacute;t, đấm, đ&aacute; v&agrave;o mặt. Th&ocirc; bạo hơn, họ c&ograve;n bắt c&ocirc; g&aacute;i quỳ, ngẩng  mặt l&ecirc;n để đ&aacute;nh v&agrave; chỉ bỏ đi sau khi đ&atilde; lột &aacute;o.</p>\n<p class="Normal" style="text-align: right;"><strong>Ho&agrave;ng Th&ugrave;y</strong></p>', '2010-10-21 15:12:10', 'ADMIN', 5, 1),
(3, 'han-quoc-nghi-trieu-tien-sap-thu-hat-nhan', 'Hàn Quốc nghi Triều Tiên sắp thử hạt nhân', 'http://localhost/mycms/images/upload/1287645605_b2.jpg', 'Triều Tiên đang tập trung người và thiết bị tại điểm thử hạt nhân hai lần trước và có thể chuẩn bị cho lần thử thứ ba, báo chí Hàn Quốc cho biết.', '<table border="0" cellspacing="0" cellpadding="3" width="1" align="left">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/50/b1.jpg" alt="Cơ sở hạt nh&acirc;n của Triều Ti&ecirc;n. Ảnh: EPA." width="250" height="195" /></td>\n</tr>\n<tr>\n<td class="Image">Cơ sở hạt nh&acirc;n Yongbyon của Triều Ti&ecirc;n. Ảnh: <em>EPA.</em></td>\n</tr>\n</tbody>\n</table>\n<p class="Lead">Triều Ti&ecirc;n đang tập trung người v&agrave; thiết bị tại điểm thử  hạt nh&acirc;n hai lần trước v&agrave; c&oacute; thể chuẩn bị cho lần thử thứ ba, b&aacute;o ch&iacute;  H&agrave;n Quốc cho biết.</p>\n<p class="Normal">Tờ <em>Chosun Ilbo</em> của H&agrave;n Quốc n&oacute;i rằng ảnh chụp  qua vệ tinh Mỹ cho thấy hoạt động của người v&agrave; phương tiện tại b&atilde;i thử  hạt nh&acirc;n của Triều Ti&ecirc;n tăng l&ecirc;n. "Hoạt động di chuyển của người v&agrave;  phương tiện tại Punggye-ri diễn ra rầm rộ gần đ&acirc;y", tờ b&aacute;o n&agrave;y dẫn nguồn  tin ch&iacute;nh phủ giấu t&ecirc;n cho hay.</p>\n<p class="Normal">B&igrave;nh Nhưỡng c&oacute; vẻ cũng đang kh&ocirc;i phục c&aacute;c đường hầm m&agrave;  họ ph&aacute; hủy trong hai vụ thử hạt nh&acirc;n lần trước. "Tuy vậy, kh&ocirc;ng c&oacute; vẻ  l&agrave; Triều Ti&ecirc;n sẽ sớm tiến h&agrave;nh vụ thử. C&oacute; thể việc chuẩn bị sẽ mất  khoảng 3 th&aacute;ng", nguồn tin n&agrave;y cho biết th&ecirc;m.</p>\n<p class="Normal">Trong khi đ&oacute;, một quan chức Bộ Quốc ph&ograve;ng H&agrave;n Quốc n&oacute;i  rằng đ&oacute; c&oacute; thể chỉ l&agrave; hoạt động bảo dưỡng c&aacute;c thiết bị chiến lược định  kỳ.</p>\n<p class="Normal">Triều Ti&ecirc;n thử hạt nh&acirc;n lần đầu ti&ecirc;n hồi th&aacute;ng 10/2006  v&agrave; lần thứ hai v&agrave;o th&aacute;ng 5/2009 tại Punggye-ri, tỉnh Bắc Hamgyong.  Th&ocirc;ng tin tr&ecirc;n được tờ <em>Chosun </em>đưa ra giữa l&uacute;c H&agrave;n Quốc chuẩn bị cho hội nghị thượng đỉnh G20.</p>\n<p class="Normal">Theo <em>AFP</em>, B&igrave;nh Nhưỡng tuy&ecirc;n bố h&ocirc;m 16/10 rằng  họ sẵn s&agrave;ng nối lại đ&agrave;m ph&aacute;n 6 b&ecirc;n về giải gi&aacute;p hạt nh&acirc;n nhưng sẽ kh&ocirc;ng  vội v&atilde; v&igrave; Mỹ v&agrave; một số nước kh&aacute;c chưa sẵn s&agrave;ng.</p>\n<p class="Normal">Washington n&oacute;i rằng B&igrave;nh Nhưỡng phải cải thiện quan hệ với Seoul v&agrave; b&agrave;y tỏ sự ch&acirc;n th&agrave;nh trước khi nối lại đ&agrave;m ph&aacute;n.</p>\n<p class="Normal">C&aacute;c cuộc đ&agrave;m ph&aacute;n s&aacute;u b&ecirc;n c&oacute; sự tham gia của Triều  Ti&ecirc;n, H&agrave;n Quốc, Trung Quốc, Nhật Bản, Nga v&agrave; Mỹ suốt mấy năm qua đ&atilde; l&acirc;m  v&agrave;o bế tắc. B&igrave;nh Nhưỡng r&uacute;t lui hồi th&aacute;ng 4/2009 để phản đối việc Li&ecirc;n  Hợp Quốc tăng cường cấm vận sau khi họ thử hạt nh&acirc;n v&agrave; t&ecirc;n lửa.</p>\n<p class="Normal" style="text-align: right;"><strong>Ngọc Sơn</strong></p>', '2010-10-21 15:21:14', 'ADMIN', 10, 1),
(4, 'vinashin-&-pha-san-theo-kieu-viet-nam', 'Vinashin & phá sản'' theo kiểu Việt Nam', 'http://localhost/mycms/images/upload/1287645742_2a.jpg', 'Trao đổi với báo chí sáng nay, Ủy viên Ủy ban Kinh tế Quốc hội Nguyễn Đức Kiên cho rằng về mặt khoa học Nhà nước đã cho Vinashin phá sản, có chăng chỉ chưa tuyên bố chính thức.', '<p class="Lead">Trao đổi với b&aacute;o ch&iacute; s&aacute;ng nay, Ủy vi&ecirc;n Ủy ban Kinh tế  Quốc hội Nguyễn Đức Ki&ecirc;n cho rằng về mặt khoa học Nh&agrave; nước đ&atilde; cho  Vinashin ph&aacute; sản, c&oacute; chăng chỉ chưa tuy&ecirc;n bố ch&iacute;nh thức.<br />&gt; <a class="Lead" href="http://vnexpress.net/GL/Kinh-doanh/2010/10/3BA21E0D/">''Kh&ocirc;ng cơ quan n&agrave;o chịu tr&aacute;ch nhiệm ch&iacute;nh về Vinashin''</a></p>\n<p class="Normal">Những rối ren tại Tập đo&agrave;n C&ocirc;ng nghiệp T&agrave;u thủy Việt  Nam (Vinashin) đang l&agrave; chủ đề sau khi Ch&iacute;nh phủ gửi b&aacute;o c&aacute;o chi tiết tới  c&aacute;c đại biểu Quốc hội chiều qua.</p>\n<p class="Normal"><em><span style="font-family: Calibri;">- V</span>ới khoản nợ l&ecirc;n tới hơn 85.000 tỷ đồng v&agrave; kh&ocirc;ng c&oacute; khả năng chi trả, theo &ocirc;ng, tại sao kh&ocirc;ng để Vinashin tuy&ecirc;n bố ph&aacute; sản?</em></p>\n<p class="Normal">- Đứng về mặt khoa học kinh tế th&igrave; Nh&agrave; nước đ&atilde; cho  Vinashin ph&aacute; sản rồi, c&oacute; điều kh&ocirc;ng tuy&ecirc;n bố th&ocirc;i. Việc chuyển đổi một  số ng&agrave;nh nghề kinh doanh sang doanh nghiệp kh&aacute;c, cơ cấu lại, chuyển đổi  m&ocirc; h&igrave;nh quản l&yacute;, t&iacute;nh to&aacute;n lại nợ&hellip; l&agrave; những biểu hiện.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/78/Photo0073.jpg" border="1" alt="Vinashin đang được cho ph&aacute; sản theo kiểu đặc th&ugrave; của Việt Nam. Ảnh: K.L" width="480" height="320" /></td>\n</tr>\n<tr>\n<td class="Image">Vinashin đang được cho ph&aacute; sản theo kiểu đặc th&ugrave; của Việt Nam. Ảnh: K.L</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Tuy nhi&ecirc;n, Vinashin l&agrave; một tập đo&agrave;n nh&agrave; nước m&agrave; Ch&iacute;nh  phủ l&agrave; chủ sở hữu. N&ecirc;n c&aacute;ch ứng xử phải kh&aacute;c. Tập đo&agrave;n ấy c&ograve;n li&ecirc;n quan  đến 7 vạn lao động đang l&agrave;m việc tại đ&acirc;y. Th&ecirc;m v&agrave;o đ&oacute;, phải đặt việc ph&aacute;  sản trong bối cảnh của năm 2010 khi m&agrave; quỹ bảo hiểm thất nghiệp mới  h&igrave;nh th&agrave;nh năm 2009 v&agrave; hiện giờ th&igrave; vẫn chưa đủ thời gian để h&igrave;nh th&agrave;nh  nguồn để chi trả.</p>\n<p class="Normal">Khi tuy&ecirc;n bố ph&aacute; sản th&igrave; doanh nghiệp kh&ocirc;ng chịu tr&aacute;ch  nhiệm về những khoản lỗ, cũng như c&aacute;c vấn đề g&igrave; nảy sinh tiếp theo với  doanh nghiệp nhưng với Vinashin th&igrave; kh&ocirc;ng thể l&agrave;m thế. Với c&aacute;ch ph&aacute; sản  đặc th&ugrave; của Vinashin, người lao động kh&ocirc;ng bị đẩy ra đường, c&aacute;c khoản nợ  ng&acirc;n h&agrave;ng vẫn được đảm bảo&hellip; v&agrave; Ch&iacute;nh phủ vẫn đảm bảo được sự ổn định vĩ  m&ocirc;.</p>\n<p class="Normal"><em>- Trong qu&aacute; tr&igrave;nh t&aacute;i cơ cấu, Vinashin chuyển một  số khoản nợ sang Petrovietnam v&agrave; Vinalines khiến nhiều người lo ngại đ&acirc;y  l&agrave; h&igrave;nh thức chuyển nợ cho doanh nghiệp nh&agrave; nước kh&aacute;c trả thay Ch&iacute;nh  phủ. &Ocirc;ng nghĩ sao?</em></p>\n<p class="Normal">- Cũng kh&ocirc;ng hẳn thế. Việc chuyển nợ k&egrave;m theo nhiều  việc kh&aacute;c l&agrave; h&igrave;nh thức để chuy&ecirc;n m&ocirc;n h&oacute;a cho Vinashin. Trước đ&acirc;y, mọi  người cứ ph&ecirc; ph&aacute;n Vinashin kinh doanh đa ng&agrave;nh, rời xa ng&agrave;nh ch&iacute;nh th&igrave;  b&acirc;y giờ t&aacute;ch ra chỉ tập trung v&agrave;o chuy&ecirc;n m&ocirc;n của họ th&ocirc;i. C&aacute;c ng&agrave;nh kh&aacute;c  th&igrave; chuyển sang doanh nghiệp c&oacute; lợi thế hơn trong kinh doanh.</p>\n<p class="Normal"><em>- Nhưng khi chuyển như vậy th&igrave; bản th&acirc;n c&aacute;c khoản nợ cũng chưa r&otilde; r&agrave;ng, tại sao kh&ocirc;ng kiểm to&aacute;n trước rồi mới chuyển?</em></p>\n<p class="Normal">- Giống như nh&agrave; c&oacute; 3 người con, một người bị bệnh  thận, &ocirc;ng bố bảo 2 người c&ograve;n lại g&oacute;p tiền để đưa đi thay thận. L&uacute;c đ&oacute;  th&igrave; kh&ocirc;ng n&ecirc;n hỏi kiểu: &ldquo;Nếu con bỏ ra 10 triệu đồng nhỡ em kh&ocirc;ng trả  được th&igrave; sao?&rdquo;. C&ugrave;ng một chủ sở hữu cả n&ecirc;n cũng kh&ocirc;ng cần thiết phải l&agrave;m  việc đ&oacute;.</p>\n<p class="Normal"><em>- Trong vụ việc tại Vinashin, b&aacute;o c&aacute;o gi&aacute;m s&aacute;t của  Quốc hội đ&atilde; c&oacute; cảnh b&aacute;o nhưng rồi những sự việc sai phạm vẫn tiếp diễn.  Tr&aacute;ch nhiệm của Quốc hội đến đ&acirc;u?</em></p>\n<p class="Normal">- Trong b&aacute;o c&aacute;o gi&aacute;m s&aacute;t về quản l&yacute; vốn của tập đo&agrave;n  năm 2009, tổ gi&aacute;m s&aacute;t c&oacute; n&oacute;i r&otilde; l&agrave; phải tiến h&agrave;nh cơ cấu lại v&agrave; ban h&agrave;nh  luật quản l&yacute; vốn v&agrave; t&agrave;i sản nh&agrave; nước. Tuy nhi&ecirc;n, khi biểu quyết th&igrave;  Quốc hội kh&ocirc;ng th&ocirc;ng qua. Ở đ&acirc;y, Quốc hội cũng c&oacute; lỗi.</p>\n<p class="Normal"><em>- Như vậy th&igrave; tr&aacute;ch nhiệm của tổ gi&aacute;m s&aacute;t ra sao?</em></p>\n<p class="Normal">- Việc đưa ra vấn đề đ&uacute;ng nhưng kh&ocirc;ng thuyết phục được  Quốc hội th&igrave; phải xem x&eacute;t lại phương ph&aacute;p thuyết phục của người được  giao nhiệm vụ đ&oacute;. Phương ph&aacute;p thuyết phục c&oacute; thể chưa đ&uacute;ng. Một v&iacute; dụ  hiển nhi&ecirc;n l&agrave; thấy đ&egrave;n đỏ phải dừng lại theo luật để đảm bảo an to&agrave;n cho  m&igrave;nh v&agrave; nhiều người kh&aacute;c, nhưng nhiều người vẫn vượt qua đ&egrave;n đỏ.</p>\n<p class="Normal" style="text-align: right;"><strong>Ho&agrave;ng Ly</strong></p>', '2010-10-23 22:32:53', 'admin', 43, 1),
(5, 'victor-vu-giao-lo-dinh-menh-giong-shattered-den-bat-ngo', 'Victor Vũ: "Giao lộ định mệnh'' giống "Shattered` đến bất ngờ', 'http://localhost/mycms/images/upload/1287645821_sub.jpg', 'Đạo diễn Việt kiều cho biết, anh rùng mình khi xem xong ''Shattered'' của đạo diễn Hollywood Wolfgang Petersen thực hiện năm 1991. Tác phẩm này và "Giao lộ định mệnh" của anh có quá nhiều điểm giống nhau.', '<p class="Lead">Đạo diễn Việt kiều cho biết, anh r&ugrave;ng m&igrave;nh khi xem xong  ''Shattered'' của đạo diễn Hollywood Wolfgang Petersen thực hiện năm 1991.  T&aacute;c phẩm n&agrave;y v&agrave; "Giao lộ định mệnh" của anh c&oacute; qu&aacute; nhiều điểm giống  nhau.  <br />&gt; <a class="Lead" href="http://vnexpress.net/GL/Van-hoa/San-khau-Dien-anh/2010/09/3BA2072B/">&lsquo;Giao lộ định mệnh&rsquo; thay đổi diện mạo phim Việt</a>/<a class="Lead" href="http://vnexpress.net/GL/Van-hoa/San-khau-Dien-anh/2010/06/3BA1D6B2/"> ''Giao lộ định mệnh'' đem hơi thở mới cho phim Việt</a></p>\n<p class="Normal">Sau hơn một th&aacute;ng <a class="Normal" href="http://vnexpress.net/GL/Van-hoa/San-khau-Dien-anh/2010/09/3BA2026D/">ra rạp tr&ecirc;n to&agrave;n quốc</a>, bộ phim <em><a href="http://search.vnexpress.net/news?s=giao+l%E1%BB%99+%C4%91%E1%BB%8Bnh+m%E1%BB%87nh&amp;g=EB7698D8-B25A-4109-B875-0115B187E1E4">Giao lộ định mệnh</a> </em>của đạo diễn<em> </em>Victor Vũ bị kh&aacute;n giả ph&aacute;t hiện l&agrave; kh&aacute; giống phim <em>Shattered </em>của Mỹ, ra mắt v&agrave;o năm 1991.</p>\n<p class="Normal">Chiều 20/10, đạo diễn phim c&oacute; cuộc trao đổi với b&aacute;o giới TP HCM để trần t&igrave;nh vụ việc.</p>\n<p class="Normal">- <em>Việc dư luận đang x&ocirc;n xao b&agrave;n t&aacute;n phim "Giao lộ  định mệnh" ăn cắp &yacute; tưởng của "Shattered" (đạo diễn Mỹ Wolfgang  Petersen), anh giải th&iacute;ch thế n&agrave;o?</em></p>\n<p class="Normal">- Mấy ng&agrave;y qua t&ocirc;i đang bận với dự &aacute;n phim mới của  m&igrave;nh n&ecirc;n kh&ocirc;ng thể trả lời những thắc mắc của nhiều người qua điện thoại  ri&ecirc;ng. Th&ecirc;m v&agrave;o đ&oacute;, khi b&aacute;o ch&iacute; phản &aacute;nh vụ việc, t&ocirc;i chưa thể trả lời  ch&iacute;nh thức v&igrave; th&uacute; thật t&ocirc;i phải t&igrave;m xem bộ phim <em>Shattered</em>. Sau khi đọc qua bảng t&oacute;m tắt nội dung<em> Shattered</em> v&agrave; xem phim tr&ecirc;n youtube, t&ocirc;i thấy quả thực hai phim c&oacute; nhiều điểm rất giống nhau.</p>\n<p class="Normal">T&ocirc;i chỉ mới xem qua <em>Shattered</em> một lần v&agrave; chưa  ph&acirc;n t&iacute;ch kỹ từng ph&acirc;n đoạn để n&ecirc;u ch&iacute;nh x&aacute;c l&agrave; hai phim giống nhau bao  nhi&ecirc;u phần trăm. Nếu n&oacute;i chung về t&igrave;nh huống, nội dung phim hay đường  d&acirc;y c&acirc;u chuyện th&igrave; r&otilde; r&agrave;ng rất giống nhau.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1D/F2/Untitled-1to0.jpg" border="1" alt="" width="400" height="616" /></td>\n</tr>\n<tr>\n<td class="Image">Poster phim "Shattered" của Hollywood sản xuất năm 1991.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">- <em>Phim "Shattered" ra mắt từ năm 1991. C&ograve;n kịch bản "Giao lộ định mệnh" được anh viết trong thời gian n&agrave;o? </em></p>\n<p class="Normal">- Từ thời c&ograve;n học điện ảnh ở Mỹ, khoảng năm 1996, t&ocirc;i  đ&atilde; c&oacute; &yacute; tưởng viết một kịch bản phim dựa tr&ecirc;n nguồn cảm hứng từ chữ  "Inferno". Từ đ&oacute; h&igrave;nh th&agrave;nh nội dung về một người bị mất tr&iacute; nhớ. Trong  qu&aacute; tr&igrave;nh đi t&igrave;m lại k&yacute; ức, anh ta ph&aacute;t hiện ch&iacute;nh anh ta l&agrave; người g&acirc;y  ra tội &aacute;c v&agrave; phải sống trong địa ngục do m&igrave;nh tạo ra.</p>\n<p class="Normal">L&uacute;c đ&oacute;, khi viết kịch bản n&agrave;y, t&ocirc;i rất t&acirc;m đắc với c&aacute;i  kết bất ngờ m&agrave; m&igrave;nh g&agrave;i v&agrave;o trong c&acirc;u chuyện. T&ocirc;i định l&agrave;m phim ngắn để  tốt nghiệp nhưng do phim tốt nghiệp phải tự m&igrave;nh bỏ kinh ph&iacute; thực hiện  m&agrave; t&ocirc;i chưa đủ khả năng n&ecirc;n đ&atilde; chọn kịch bản kh&aacute;c.</p>\n<p class="Normal">Từ đ&oacute; đến nay, những file vi t&iacute;nh ban đầu t&ocirc;i viết kịch bản <em>Inferno</em> cũng đ&atilde; mất hết. Khi bắt tay v&agrave;o thực hiện bộ phim <em>Giao lộ định mệnh</em>,  t&ocirc;i phải viết lại dựa tr&ecirc;n &yacute; tưởng t&acirc;m đắc từ hơn 10 năm trước của  ch&iacute;nh m&igrave;nh. Một điều t&ocirc;i chắc chắn l&agrave; t&ocirc;i chưa từng xem phim <em>Shattered</em> trước thời điểm viết kịch bản n&agrave;y. C&oacute; thể l&agrave; t&ocirc;i c&oacute; nghe n&oacute;i đến bởi  phim n&agrave;y cũng thuộc dạng c&oacute; tiếng. T&ocirc;i nghĩ sự giống nhau giữa hai bộ  phim l&agrave; một sự tr&ugrave;ng hợp ho&agrave;n to&agrave;n bất ngờ. Thực ra, hai phim vẫn c&oacute;  điểm kh&aacute;c nhau.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1D/F2/posetrto.jpg" border="1" alt="" width="400" height="566" /></td>\n</tr>\n<tr>\n<td class="Image">Poster phim "Giao lộ định mệnh".</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal"><em>- Đạo diễn"Shattered" ghi r&otilde;, phim dựa tr&ecirc;n tiểu  thuyết của nh&agrave; văn Richard Neely. C&oacute; thể anh cũng đọc qua t&aacute;c phẩm n&agrave;y  v&agrave; bị &aacute;m ảnh bởi c&aacute;c chi tiết trong đ&oacute;?</em></p>\n<p class="Normal">- Hồi trẻ t&ocirc;i cũng đọc truyện trinh th&aacute;m nhiều nhưng  t&ocirc;i chưa bao giờ đọc t&aacute;c phẩm của Richard Neely. T&ocirc;i rất tin tưởng v&agrave;o  tr&iacute; nhớ của m&igrave;nh.</p>\n<p class="Normal">- <em>C&oacute; những chi tiết n&agrave;o giống nhau giữa hai phim khiến anh bất ngờ?</em></p>\n<p class="Normal">- T&ocirc;i xem phim <em>Shattered</em> c&ugrave;ng anh thiết kế,  v&agrave; cả hai ch&uacute;ng t&ocirc;i đều rất bất ngờ v&igrave; c&oacute; những chi tiết m&agrave; ch&uacute;ng t&ocirc;i  chỉ đạo cho diễn vi&ecirc;n hoặc xử l&yacute; ngay tại phim trường <em>Giao lộ định mệnh</em> m&agrave; vẫn giống với phim kia. Những chi tiết như vết sẹo của nh&acirc;n vật,  c&aacute;ch nh&acirc;n vật cầm gậy rồi chuyện ngoại t&igrave;nh với c&ocirc; thư k&yacute;... l&agrave; những  điểm giống khiến t&ocirc;i phải run người. V&igrave; nếu giống đường d&acirc;y c&acirc;u chuyện  trong bộ phim th&igrave; cũng l&agrave; b&igrave;nh thường, nhưng c&ograve;n giống đến từng t&igrave;nh  tiết nhỏ như thế th&igrave; thật bất ngờ.</p>\n<table border="0" cellspacing="1" cellpadding="3" width="300" align="center" bgcolor="#408080">\n<tbody>\n<tr>\n<td class="Normal" align="center" bgcolor="#ffffff">* <a class="Normal" href="http://vnexpress.net/GL/Van-hoa/2010/10/3BA21DF2/page_3.asp">Trailer phim ''Shattered''</a></td>\n</tr>\n<tr>\n<td class="Normal" align="center" bgcolor="#ffffff">* <a class="Normal" href="http://vnexpress.net/GL/Van-hoa/2010/10/3BA21DF2/page_2.asp">Trailer phim ''Giao lộ định mệnh''</a></td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">- <em>Anh l&yacute; giải thế n&agrave;o về sự giống nhau "kỳ lạ" như thế?</em></p>\n<p class="Normal">- Nếu l&agrave; d&acirc;n trong nghề th&igrave; c&oacute; thể hiểu v&agrave; th&ocirc;ng cảm.  T&ocirc;i từng n&oacute;i nhiều lần, phim n&agrave;y t&ocirc;i l&agrave;m theo phong c&aacute;ch Hollywood v&agrave;  theo trường ph&aacute;i Alfred Hitchcock. Thường th&igrave; phim Hollywood c&oacute; sẵn  những dạng khu&ocirc;n mẫu ri&ecirc;ng của n&oacute;. Từ những khu&ocirc;n mẫu n&agrave;y m&agrave; đường d&acirc;y  v&agrave; t&igrave;nh tiết ph&aacute;t triển c&acirc;u chuyện, nh&acirc;n vật được triển khai. Phim  Hollywood cũng thường c&oacute; v&agrave;i m&ocirc; t&iacute;p v&agrave; c&ocirc;ng thức m&agrave; họ đảo đi đảo lại  rồi đặt th&ecirc;m chi tiết để l&agrave;m hấp dẫn th&ecirc;m.</p>\n<p class="Normal">Điều bất ngờ l&agrave; ngay từ đầu <em>Giao lộ định mệnh</em> v&agrave; <em>Shatttered</em> đ&atilde; giống nhau về &yacute; tưởng v&agrave; bản chất nội dung n&ecirc;n trong c&aacute;i khung sẵn  đ&oacute;, những đường d&acirc;y để ph&aacute;t triển nh&acirc;n vật, ph&aacute;t triển nội dung kh&oacute;  tr&aacute;nh khỏi c&oacute; sự giống nhau.</p>\n<p class="Normal">Nếu ngay từ đầu t&ocirc;i biết về sự giống nhau n&agrave;y hoặc được bạn b&egrave; chỉ ra cho l&agrave; c&oacute; một kịch bản phim <em>Shattered</em> giống phim m&igrave;nh muốn l&agrave;m th&igrave; t&ocirc;i đ&atilde; tr&aacute;nh kh&ocirc;ng l&agrave;m giống nhau đến như thế.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1D/F2/anhto.jpg" border="1" alt="" width="485" height="322" /></td>\n</tr>\n<tr>\n<td class="Image">Một cảnh trong phim "Giao lộ định mệnh".</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal"><em>- Vậy theo anh sự kh&aacute;c nhau giữa "Giao lộ định mệnh" v&agrave; "Shattered" l&agrave; g&igrave;?</em></p>\n<p class="Normal">- Nh&acirc;n vật Mạnh bị mất tr&iacute; nhớ v&agrave; anh ta phải tiếp x&uacute;c  với rất nhiều người để lần t&igrave;m về qu&aacute; khứ của m&igrave;nh. Điểm n&agrave;y kh&aacute;c biệt  với nh&acirc;n vật trong phim <em>Shattered.</em></p>\n<table border="1" cellspacing="0" cellpadding="3" width="257" align="right" bgcolor="#eff8f8">\n<tbody>\n<tr>\n<td>\n<p class="Normal">Irene Trịnh (Nh&agrave; sản xuất phim <em>Giao lộ định mệnh</em>) cho biết: "Từ khi bắt tay v&agrave;o viết kịch bản để thực hiện <em>Giao lộ định mệnh</em>,  đạo diễn Victor Vũ cũng đ&atilde; tr&ograve; chuyện với t&ocirc;i rất nhiều về &yacute; tưởng thực  hiện bộ phim. Trong qu&aacute; tr&igrave;nh n&agrave;y, ch&uacute;ng t&ocirc;i c&ugrave;ng anh em trong đo&agrave;n l&agrave;m  phim cũng đ&oacute;ng g&oacute;p nhiều &yacute; kiến để Victor Vũ ho&agrave;n th&agrave;nh kịch bản. V&igrave;  thế, khi phim ra mắt th&igrave; đ&acirc;y l&agrave; sản phẩm hợp t&aacute;c của cả đo&agrave;n l&agrave;m phim  chứ kh&ocirc;ng chỉ của ri&ecirc;ng đạo diễn. Từ kịch bản để trở th&agrave;nh một bộ phim  th&igrave; ch&uacute;ng t&ocirc;i cũng phải thay đổi rất nhiều thứ. Giả sử nếu ch&uacute;ng t&ocirc;i  biết trước đ&acirc;y l&agrave; kịch bản phim n&agrave;y giống một phim nổi tiếng n&agrave;o kh&aacute;c  th&igrave; ch&uacute;ng t&ocirc;i rất vui l&ograve;ng để th&ecirc;m d&ograve;ng "phim x&acirc;y dựng dựa tr&ecirc;n nguồn  cảm hứng từ phim A, B, C... n&agrave;o đ&oacute;.</p>\n<p class="Normal">T&ocirc;i nghĩ sự giống nhau giữa <em>Giao lộ định mệnh</em> v&agrave; <em>Shattered</em> l&agrave; một sự tr&ugrave;ng hợp qu&aacute; bất ngờ."</p>\n</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal"><em>- Giả sử, nếu nh&agrave; sản xuất phim Mỹ kiện th&igrave; anh c&oacute; c&aacute;ch n&agrave;o để chứng minh?</em></p>\n<p class="Normal">- T&ocirc;i chưa nghĩ xa đến điều đ&oacute;. T&ocirc;i nghĩ, m&igrave;nh l&agrave;m  trong nghề n&ecirc;n m&igrave;nh hiểu việc cần t&ocirc;n trọng c&aacute;c nh&agrave; l&agrave;m phim kh&aacute;c. Thật  l&agrave; v&ocirc; l&yacute; nếu t&ocirc;i biết c&oacute; một phim như thế m&agrave; lại đi l&agrave;m giống y hệt, thể  hiện sự sao ch&eacute;p một c&aacute;ch r&otilde; r&agrave;ng để mọi người c&oacute; thể ph&aacute;t hiện ra. L&agrave;m  phim l&agrave; một qu&aacute; tr&igrave;nh s&aacute;ng tạo phức tạp. T&ocirc;i đ&atilde; đổ mồ h&ocirc;i, nước mắt cho  <em>Giao lộ định mệnh</em> th&igrave; kh&ocirc;ng thể dễ d&agrave;ng l&agrave;m phim sao ch&eacute;p &yacute; tưởng.</p>\n<p class="Normal">T&ocirc;i c&oacute; cảm gi&aacute;c nếu đo&agrave;n phim b&ecirc;n kia m&agrave; c&oacute; xem <em>Giao lộ định mệnh</em> th&igrave; họ cũng sẽ hiểu v&agrave; th&ocirc;ng cảm cho t&ocirc;i về sự tr&ugrave;ng hợp n&agrave;y.</p>\n<p class="Normal"><em>- Điều n&agrave;y g&acirc;y cản trở g&igrave; cho dự định ph&aacute;t h&agrave;nh phim ở Mỹ?</em></p>\n<p class="Normal">- Thực tế, phim đang trong dự t&iacute;nh ph&aacute;t h&agrave;nh ở Mỹ. Đ&acirc;y  l&agrave; kế hoạch t&ocirc;i đặt ra từ đầu, khi bắt tay thực hiện phim. T&ocirc;i sinh  trưởng v&agrave; học h&agrave;nh ở Mỹ. Thật sự khi t&ocirc;i về nước l&agrave;m phim l&agrave; vừa để phục  vụ kh&aacute;n giả trong nước nhưng cũng đều mong muốn mang phim của m&igrave;nh giới  thiệu với kh&aacute;n giả tại Mỹ. Cho n&ecirc;n, n&oacute;i t&ocirc;i muốn che giấu th&ocirc;ng tin  "đạo" phim l&agrave; kh&ocirc;ng đ&uacute;ng.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1D/F2/top.jpg" border="1" alt="" width="485" height="351" /></td>\n</tr>\n<tr>\n<td class="Image">Đạo diễn Victor Vũ (phải) v&agrave; nh&agrave; s&agrave;n xuất Irene Trịnh trong cuộc gặp gỡ b&aacute;o ch&iacute; TP HCM.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal"><em>- Anh c&ograve;n điều g&igrave; muốn b&agrave;y tỏ với kh&aacute;n giả, những người y&ecirc;u mến "Giao lộ định mệnh"?</em></p>\n<p class="Normal">- Thật sự đ&acirc;y l&agrave; một việc hết sức đ&aacute;ng tiếc cho t&ocirc;i. C&ograve;n mọi người nghĩ thế n&agrave;o th&igrave; nằm ngo&agrave;i kiểm so&aacute;t của t&ocirc;i rồi.</p>\n<p class="Normal">L&agrave; một đạo diễn với l&ograve;ng tự trọng nghề nghiệp, t&ocirc;i  kh&ocirc;ng thể n&agrave;o muốn l&agrave;m ra một sản phẩm giống ho&agrave;n to&agrave;n với một phim  kh&aacute;c. Mỗi phim t&ocirc;i l&agrave;m ra đều cố gắng mang v&agrave;o &yacute; tưởng mới lạ của bản  th&acirc;n m&igrave;nh. T&ocirc;i lu&ocirc;n nghi&ecirc;m t&uacute;c trong c&ocirc;ng việc v&igrave; đ&acirc;y l&agrave; đam m&ecirc;. T&ocirc;i  mong mọi người hiểu t&ocirc;i kh&ocirc;ng thể n&agrave;o bỏ ra biết bao c&ocirc;ng sức v&agrave; thời  gian để l&agrave;m một phim qu&aacute; giống một phim kh&aacute;c như thế, giống đến nỗi mỗi  người c&oacute; thể ph&aacute;t hiện ra một c&aacute;ch dễ d&agrave;ng.</p>\n<p class="Normal">Ph&aacute;n x&eacute;t v&agrave; quyết định l&agrave; của kh&aacute;n giả chứ kh&ocirc;ng c&ograve;n nằm ở t&ocirc;i nữa.</p>', '2010-10-21 15:27:19', 'ADMIN', 6, 1),
(6, 'messi-lap-dai-cong-giup-barca-chiem-ngoi-dau-bang', 'Messi lập đại công giúp Barca chiếm ngôi đầu bảng', 'http://localhost/mycms/images/upload/1287646690_mes2.jpg', 'Tiền đạo người Argentina ghi cả hai bàn trong trận Barca thắng Copenhagen với kết quả 2-0 ở vòng bảng Champions League tối thứ 4.', '<p class="Lead">Tiền đạo người Argentina ghi cả hai b&agrave;n trong trận Barca  thắng Copenhagen với kết quả 2-0 ở v&ograve;ng bảng Champions League tối thứ  tư.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/21/mes.jpg" border="1" alt="Busquets v&agrave; Abidal ch&uacute;c mừng Messi sau pha ấn định tỷ số." width="399" height="298" /></td>\n</tr>\n<tr>\n<td class="Image">Busquets v&agrave; Abidal ch&uacute;c mừng Messi sau pha ấn định tỷ số.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Hai b&agrave;n của Messi chỉ l&agrave; th&agrave;nh quả của hai trong số nhiều cơ hội d&agrave;nh cho đội chủ nh&agrave; trong trận đấu tại s&acirc;n Nou Camp.</p>\n<table border="0" cellspacing="1" cellpadding="3" width="250" align="right" bgcolor="#408080">\n<tbody>\n<tr>\n<td class="PnDTitle" align="center" bgcolor="#408080">Lượt trận thứ ba v&ograve;ng bảng</td>\n</tr>\n<tr>\n<td class="PnLink" align="left" bgcolor="#ffffff">Thứ ba, ng&agrave;y 19/10 <br />Bảng E<br /><strong>Roma 1-3 Basel</strong><br />(Borriello 21'' - Frei 12'', Inkoom 44'', Cabral 90''+3)<br /><strong>Bayern 3-2 Cluj</strong><br />(Cadu phản lưới nh&agrave; 32'', Panin phản lưới nh&agrave; 37'', Gomez 77'' - Cadu 28'', Culio 86'')<br /><br />Bảng F<br /><strong>Spartak Moscow 0-2 Chelsea</strong><br />(Zhirkov 23'', Anelka 43'')<br /><strong>Marseille 1-0 Zilina</strong><br />(Diawara 48'')<br /><br />Bảng G<br /><strong>Real Madrid 2-0 Milan</strong><br />(Ronaldo 13'', Oezil 14'')<br /><strong>Ajax 2-1 Auxerre</strong><br />(De Zeeuw 7'', Suarez 41'' - Birsa 56'')<br /><br />Bảng H<br /><strong>Arsenal 5-1 Shakhtar Donetsk</strong><br />(Song 19'', Nasri 42'', Fabregas pen 60'', Wilshere 66'', Chamakh 69'' - Eduardo 82'')<br /><strong>Braga 2-0 Partizan Belgrade</strong><br />(Lima 35'', Matheus 90'')<br /><br />Thứ tư, ng&agrave;y 20/10 <br />Bảng A<br /><strong>Inter 4-3 Tottenham</strong> <br />(Zanetti 2'', Eto''o 11'' pen, 35'', Stankovic 14'' - Bale 52'', 90'', 90''+1)<br /><strong>Twente 1-1 Bremen<br /></strong>(Janssen 75'' - Arnautovic 80'')<br /><br />Bảng B <br /><strong>Schalke 3-1 Hapoel Tel Aviv </strong><br />(Raul 3'', 58'', Jurado 68'' -Shechter 90''+4)<br /><strong>Lyon 2-0 Benfica<br /></strong>(Briand 21'', Lopez 51'')<br /><br />Bảng C <br /><strong>Rangers 1-1 Valencia <br /></strong>(Edu 34'' - Edu 46'' phản lưới)<br /><strong>MU 1-0 Bursaspor</strong> <br />(Nani 7'')<br /><br />Bảng D<br /><strong>Panathinaikos 0-0 Rubin Kazan </strong><br /><strong>Barca 2-0 Copenhagen<br /></strong>(Messi 19'', 90''+2'')</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">B&agrave;n đầu ti&ecirc;n được Messi thực hiện ở ph&uacute;t 19 bằng một  c&uacute; s&uacute;t xa v&agrave;o g&oacute;c cao. Sau khi Barca trải qua hiệp hai kh&aacute; căng thẳng,  b&agrave;n thứ hai được ghi trong khoảng thời gian đ&aacute; b&ugrave;.</p>\n<p class="Normal">Thủ m&ocirc;n Wiland đ&atilde; cứu thua cho Copenhagen trước một  loạt pha dứt điểm của Messi, David Villa v&agrave; Daniel Alves, nhưng tiền đạo  đội kh&aacute;ch Cesar Martin cũng bỏ lỡ kh&ocirc;ng &iacute;t cơ hội tốt c&ograve;n đồng đội Dame  N&rsquo;Doye c&oacute; một c&uacute; s&uacute;t bật x&agrave;.</p>\n<p class="Normal">Chiến thắng tối qua đ&atilde; đem lại vị tr&iacute; dẫn đầu bảng D  v&agrave; 7 điểm cho đội b&oacute;ng T&acirc;y Ban Nha, hơn Copenhagen 1 điểm. Rubin Kazan  c&oacute; 2 điểm v&agrave; Panathinaikos c&oacute; 1 điểm sau khi hai đội n&agrave;y h&ograve;a trong trận  c&ograve;n lại.</p>\n<p class="Normal">So với trận thắng Valencia 2-1 cuối tuần trước, trận  đấu được HLV Pep Guardiola ca ngợi l&agrave; "cuộc lột x&aacute;c của đội b&oacute;ng", Barca  đ&atilde; c&oacute; nhiều thay đổi trong danh s&aacute;ch xuất ph&aacute;t. Thủ m&ocirc;n dự bị Jose  Manuel Pinto bắt thay Victor Valdes, người bị chấn thương nhẹ ở đầu gối.  Xavi Hernandez chưa hết đau g&acirc;n kheo v&agrave; được Guardiola cho ngồi ghế dự  bị. Đ&aacute; thay tiền vệ "nhạc trưởng" của Barca l&agrave; t&acirc;n binh Javier  Mascherano.</p>\n<p class="Normal">Với lối chơi chuyền ban ngắn sở trường, Barca nhanh  ch&oacute;ng chiếm ưu thế nhưng đội kh&aacute;ch kh&ocirc;ng bị cho&aacute;ng ngợp. Bầu kh&ocirc;ng kh&iacute;  tại s&acirc;n Nou Camp trở n&ecirc;n s&ocirc;i động từ ph&uacute;t thứ tư, khi Villa s&uacute;t tr&uacute;ng x&agrave;  ngang Copenhagen. Villa l&agrave; người ghi b&agrave;n trong cả hai trận trước ở v&ograve;ng  bảng.</p>\n<p class="Normal">Thủ m&ocirc;n Wiland tỏ ra xuất sắc trong t&igrave;nh huống v&ocirc; hiệu  h&oacute;a cơ hội của Maxwell v&agrave; Messi ở ph&uacute;t 17, nhưng anh kh&ocirc;ng cản được c&uacute;  s&uacute;t như đại b&aacute;c của Messi ở ph&uacute;t 19.</p>\n<p class="Normal">Trong t&igrave;nh huống đ&oacute;n đường chuyền của Andres Iniesta,  tiền đạo người Argentina dứt điểm quyết đo&aacute;n từ cự ly 25 m khiến b&oacute;ng  bay v&agrave;o g&oacute;c cao. Đ&acirc;y l&agrave; b&agrave;n thứ ba của Messi ở Champions League  2010-2011, đồng thời l&agrave; pha thủng lưới đầu ti&ecirc;n của Copenhagen, khiến kế  hoạch ph&ograve;ng ngự chiều s&acirc;u kết hợp phản c&ocirc;ng của họ bị ph&aacute; sản.</p>\n<p class="Normal">Ph&uacute;t 32, Wiland tiếp tục từ chối nỗ lực dứt điểm của  Villa. Messi c&oacute; th&ecirc;m một lần đưa b&oacute;ng v&agrave;o lưới đối phương trong hiệp một  nhưng bị trọng t&agrave;i thổi việt vị.</p>\n<p class="Normal">Sau khi kh&ocirc;ng tung được c&uacute; s&uacute;t ra hồn n&agrave;o trong hiệp  một th&igrave; Copenhagen bỗng chơi lột x&aacute;c sau giờ nghỉ. Trong l&uacute;c Barca cố  gắng giải quyết trận đấu, đội kh&aacute;ch đ&atilde; chứng tỏ năng lực tổ chức ph&ograve;ng  ngự v&agrave; c&oacute; nhiều phương &aacute;n phản c&ocirc;ng đa dạng.</p>\n<p class="Normal">Ph&uacute;t 48, N&rsquo;Doye bỏ lỡ cơ hội đ&aacute;nh đầu sau một quả tạt  như đặt. Ph&uacute;t 67, cầu thủ n&agrave;y tiếp tục uy hiếp khung th&agrave;nh thủ m&ocirc;n Jose  Pinto. C&uacute; s&uacute;t đầu ti&ecirc;n tưởng sẽ th&agrave;nh c&ocirc;ng th&igrave; b&oacute;ng dội x&agrave; ngang. Trong  khi Pinto mất đ&agrave; v&agrave; khung th&agrave;nh bị bỏ trống, Cesar Martin đ&atilde; đ&aacute;nh đầu  bồi ra ngo&agrave;i.</p>\n<p class="Normal">HLV Guardiola sau đ&oacute; buộc phải tung Xavi v&agrave; tiền đạo  Pedro v&agrave;o s&acirc;n. Ph&uacute;t 74 Dani Alves c&oacute; c&uacute; xoạc b&oacute;ng kịp thời giải nguy cho  Barca trong t&igrave;nh huống uy hiếp của Christian Bolanos. Hậu vệ người  Brazil c&ograve;n c&oacute; c&uacute; s&uacute;t đập cột dọc của Copenhagen ở ph&uacute;t 87.</p>\n<p class="Normal">Sau khi trận đấu tưởng chừng an b&agrave;i với tỷ số 1-0,  trong t&igrave;nh huống tấn c&ocirc;ng ở những ph&uacute;t cuối, Messi ghi được b&agrave;n ấn định  chiến thắng. Tiền đạo người Argentina dứt điểm dễ d&agrave;ng sau khi Eric  Abidal c&oacute; c&uacute; v&ocirc;l&ecirc; kh&ocirc;ng ch&iacute;nh x&aacute;c, v&ocirc; t&igrave;nh biến th&agrave;nh đường chuyền tốt  cho đồng đội.</p>\n<p class="Normal"><strong><a href="http://vnexpress.net/GL/The-thao/2010/10/3BA21E21/Page_2.asp">Xem b&agrave;n mở tỷ số của Messi</a></strong>.</p>\n<p class="Normal"><strong><a href="http://vnexpress.net/GL/The-thao/2010/10/3BA21E21/Page_3.asp">Messi ấn định chiến thắng</a></strong>.</p>\n<p class="Normal"><strong><span style="color: #4f4f4f;">Đội h&igrave;nh thi đấu:</span></strong></p>\n<p class="Normal"><strong><span style="color: #4f4f4f;">Barcelona:</span></strong> Pinto; Alves, Piqu&eacute;, Puyol, Abidal; Mascherano, Busquets, Iniesta (Keita, 89''), Maxwell (Pedro, 72''); Villa (Xavi, 72''), Messi.</p>\n<p class="Normal"><strong><span style="color: #4f4f4f;">Copenhague:</span></strong> Wiland; Pospech, Antonsson, Zanka Jorgensen, Wendt (Larsson, 89'');  Vingaard (Bola&ntilde;os, 62''), Claudemir, Kvist, Gronkjaer; Santin (Zohore,  74''), N''Doye.</p>\n<p class="Normal"><strong><span style="color: #4f4f4f;">Bảng D</span></strong></p>\n<p><strong>&nbsp;</strong></p>\n<table border="1" cellspacing="1" cellpadding="1" width="300" align="center">\n<tbody>\n<tr>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">TT</span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">Đội </span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">Trận</span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">T</span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">H</span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">B</span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">H/S</span></strong></td>\n<td class="Normal" align="middle"><strong><span style="color: #3f3f3f;">Điểm</span></strong></td>\n</tr>\n<tr>\n<td class="Normal" align="middle">1</td>\n<td class="Normal" align="middle">Barcelona</td>\n<td class="Normal" align="middle">3</td>\n<td class="Normal" align="middle">2</td>\n<td class="Normal" align="middle">1</td>\n<td class="Normal" align="middle">0</td>\n<td class="Normal" align="middle">6</td>\n<td class="Normal" align="middle">7</td>\n</tr>\n<tr>\n<td class="Normal" align="middle">2</td>\n<td class="Normal" align="middle">Copenhagen</td>\n<td class="Normal" align="middle">3</td>\n<td class="Normal" align="middle">2</td>\n<td class="Normal" align="middle">0</td>\n<td class="Normal" align="middle">1</td>\n<td class="Normal" align="middle">1</td>\n<td class="Normal" align="middle">6</td>\n</tr>\n<tr>\n<td class="Normal" align="middle">3</td>\n<td class="Normal" align="middle">Rubin Kazan</td>\n<td class="Normal" align="middle">3</td>\n<td class="Normal" align="middle">0</td>\n<td class="Normal" align="middle">2</td>\n<td class="Normal" align="middle">1</td>\n<td class="Normal" align="middle">-1</td>\n<td class="Normal" align="middle">2</td>\n</tr>\n<tr>\n<td class="Normal" align="middle">4</td>\n<td class="Normal" align="middle">Panathinaikos</td>\n<td class="Normal" align="middle">3</td>\n<td class="Normal" align="middle">0</td>\n<td class="Normal" align="middle">1</td>\n<td class="Normal" align="middle">2</td>\n<td class="Normal" align="middle">-6</td>\n<td class="Normal" align="middle">1</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal" style="text-align: right;"><strong>Th&uacute;y An</strong></p>', '2010-10-22 16:53:53', 'nclong', 39, 1),
(7, 'bep-com-cuu-doi-cho-nguoi-dan-o-ron-lu', 'Bếp cơm cứu đói cho người dân ở rốn lũ', 'http://localhost/mycms/images/upload/1287647107_cuu1.jpg', 'Từ 3 ngày nay, những chiếc xuống nhỏ mang theo rổ cơm nắm lặng lẽ vượt qua biển nước tới từng gia đình tại các xã ngập sâu ở huyện Vũ Quang, Hà Tĩnh. Những nắm cơm được trao vội trong cái nhìn biết ơn của người dân.', '<p class="Lead">Từ 3 ng&agrave;y nay, những chiếc xuống nhỏ mang theo rổ cơm  nắm lặng lẽ vượt qua biển nước tới từng gia đ&igrave;nh tại c&aacute;c x&atilde; ngập s&acirc;u ở  huyện Vũ Quang, H&agrave; Tĩnh. Những nắm cơm được trao vội trong c&aacute;i nh&igrave;n biết  ơn của người d&acirc;n.<br />&gt; <a class="Lead" href="http://vnexpress.net/GL/Doi-song/2010/10/3BA21D6C/">Chật vật kiếm ăn giữa biển nước miền Trung</a></p>\n<p class="Normal">"Sau nhiều ng&agrave;y người d&acirc;n v&ugrave;ng ngập chỉ sống cầm hơi  bằng m&igrave; g&oacute;i v&agrave; lương kh&ocirc;, huyện đ&atilde; đưa ra s&aacute;ng kiến nấu cơm nắm đi ph&aacute;t  cứu tế. Nh&igrave;n những đứa trẻ hồ hởi mở g&oacute;i cơm ăn, hạt d&iacute;nh đầy tr&ecirc;n m&aacute; m&agrave;  ch&uacute;ng t&ocirc;i rơi nước mắt", &ocirc;ng Nguyễn Hồng Lĩnh, Ph&oacute; B&iacute; thư Huyện ủy  huyện Vũ Quang, một trong những điểm ngập s&acirc;u nhất của H&agrave; Tĩnh, cho  biết.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="247" align="center" bgcolor="#e2c5c5">\n<tbody>\n<tr>\n<td class="Normal" align="center"><a class="Normal" href="http://vnexpress.net/GL/Doi-song/2010/10/3BA21E6F/page_2.asp"><strong>Clip nắm cơm cứu đ&oacute;i v&ugrave;ng rốn lũ</strong></a></td>\n</tr>\n</tbody>\n</table>\n<table border="0" cellspacing="0" cellpadding="3" width="100%">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6F/nau1.jpg" border="1" alt="" width="490" height="392" /></td>\n</tr>\n<tr>\n<td class="Image">S&aacute;ng kiến nấu cơm nắm đi cứu tế đến từng hộ được đưa  ra mới đ&acirc;y đ&atilde; được hưởng ứng rộng r&atilde;i. Lực lượng tham gia l&agrave; chị em phụ  nữ ở c&aacute;c x&atilde; kh&ocirc;ng bị ngập trong huyện Vũ Quang.</td>\n</tr>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6F/nau6.jpg" border="1" alt="" width="490" height="385" /></td>\n</tr>\n<tr>\n<td class="Image">C&aacute;c bếp nấu được đặt ở những nơi kh&ocirc; r&aacute;o, hoặc tại nơi  ngập &iacute;t. Cơm sau khi nấu được nắm th&agrave;nh từng g&oacute;i, v&agrave; được chở xuồng đi  ph&aacute;t đến từng hộ d&acirc;n.</td>\n</tr>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6F/nau3.jpg" border="1" alt="" width="490" height="348" /></td>\n</tr>\n<tr>\n<td class="Image">C&aacute;c x&atilde; nhận được cơm nắm l&agrave; những nơi ngập s&acirc;u trong  huyện Vũ Quang như Hương Nguy&ecirc;n, Đức Li&ecirc;n, Đức Bồng, Đức Hương. Nhiều  người trong số họ đ&atilde; kh&ocirc;ng biết đến miếng cơm cả tuần nay.</td>\n</tr>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6F/nau4.jpg" border="1" alt="" width="490" height="371" /></td>\n</tr>\n<tr>\n<td class="Image">C&aacute;c b&agrave;, c&aacute;c chị qu&acirc;y quần b&ecirc;n nắm cơm ấm l&ograve;ng.</td>\n</tr>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6F/nau5.jpg" border="1" alt="" width="490" height="360" /></td>\n</tr>\n<tr>\n<td class="Image">"Nhận được nắm cơm ấm l&ograve;ng, người d&acirc;n hết sức vui mừng v&agrave; cảm động", &ocirc;ng Nguyễn Hồng Lĩnh cho biết.</td>\n</tr>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6F/nau2.jpg" border="1" alt="" width="490" height="387" /></td>\n</tr>\n<tr>\n<td class="Image">Ngo&agrave;i c&aacute;c bếp nấu cơm nắm đi cứu tế, một số bếp d&atilde;  chiến hoặc bếp tập thể cũng được dựng l&ecirc;n ở ngay c&aacute;c x&atilde; n&agrave;y, cung cấp  bữa ăn chủ yếu cho người gi&agrave; v&agrave; trẻ nhỏ.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal" style="text-align: right;"><strong>Nguy&ecirc;n Khoa - Nguyễn Hưng</strong></p>', '2010-10-21 15:45:37', 'ADMIN', 18, 1);
INSERT INTO `articles` (`id`, `alias`, `title`, `imagedes`, `contentdes`, `content`, `datemodified`, `usermodified`, `viewcount`, `active`) VALUES
(8, 'nhung-chuyen-than-bi-quanh-nguoi-rung-o-trung-quoc', 'Những chuyện thần bí quanh ''người rừng'' ở Trung Quốc', 'http://localhost/mycms/images/upload/1287647165_yk2.jpg', 'Nhiều nhân chứng kể rằng các nữ dã nhân tại Trung Quốc đột nhập vào một số làng trong rừng để tìm kiếm đàn ông.', '<p class="Lead">Nhiều nh&acirc;n chứng kể rằng c&aacute;c nữ d&atilde; nh&acirc;n tại Trung Quốc đột nhập v&agrave;o một số l&agrave;ng trong rừng để t&igrave;m kiếm đ&agrave;n &ocirc;ng.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1D/FF/Yeren2.jpg" alt="C&aacute;c nh&agrave; khoa học t&igrave;m thấy " width="450" height="281" /></td>\n</tr>\n<tr>\n<td class="Image">C&aacute;c nh&agrave; khoa học t&igrave;m thấy "l&ocirc;ng d&atilde; nh&acirc;n" trong rừng Thần N&ocirc;ng Gia, tỉnh Hồ Bắc, Trung Quốc trong thập ni&ecirc;n 80. Ảnh: <em>Xinhua</em>.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Hơn 400 người Trung Quốc khẳng định họ từng nh&igrave;n thấy  d&atilde; nh&acirc;n - sinh vật giống người hoặc đười ươi song lại c&oacute; chiều cao tới 2  m - trong rừng Thần N&ocirc;ng Gia thuộc tỉnh Hồ Bắc. Chẳng hạn, v&agrave;i người kể  rằng c&aacute;c d&atilde; nh&acirc;n nữ đột nhập v&agrave;o một số l&agrave;ng trong rừng để ngủ với đ&agrave;n  &ocirc;ng. Năm 1983, tờ <em>Nhật b&aacute;o Chiết Giang</em> đưa tin một n&ocirc;ng  d&acirc;n đang ngủ trong chiếc l&aacute;n trong rừng th&igrave; một sinh vật to lớn c&oacute; h&igrave;nh  dạng giống phụ nữ lao v&agrave;o l&aacute;n v&agrave; định thực hiện h&agrave;nh vi giao cấu với  anh. Sinh vật đ&oacute; c&oacute; cặp mắt m&agrave;u xanh dương thẫm.</p>\n<p class="Normal">&ldquo;Người n&ocirc;ng d&acirc;n kh&ocirc;ng k&ecirc;u được v&igrave; qu&aacute; sợ h&atilde;i. Anh cũng  kh&ocirc;ng thể chống cự được đối thủ. Nữ d&atilde; nh&acirc;n kia giao cấu với anh trong  v&agrave;i ph&uacute;t rồi bỏ đi&rdquo;, tờ b&aacute;o kể.</p>\n<p class="Normal">Lời đồn đại về sự tồn tại của d&atilde; nh&acirc;n khiến hơn 100  nh&agrave; khoa học th&agrave;nh lập Hiệp hội T&igrave;m kiếm d&atilde; nh&acirc;n Hồ Bắc v&agrave;o th&aacute;ng  11/2009. Wang Shancai, một ph&oacute; chủ tịch của hiệp hội, cho biết, c&aacute;c nh&agrave;  khoa học đang quy&ecirc;n tiền để thực hiện một cuộc t&igrave;m kiếm d&atilde; nh&acirc;n quy m&ocirc;  lớn trong rừng Thần N&ocirc;ng Gia. Theo &ocirc;ng Wang, nếu d&atilde; nh&acirc;n thực sự tồn  tại, ch&uacute;ng sẽ gi&uacute;p giới khoa học hiểu r&otilde; hơn qu&aacute; tr&igrave;nh động vật linh  trưởng tiến h&oacute;a th&agrave;nh người.</p>\n<p class="Normal">Viện Khoa học Trung Quốc từng cử ba đo&agrave;n chuy&ecirc;n gia  v&agrave;o rừng Thần N&ocirc;ng Gia để t&igrave;m d&atilde; nh&acirc;n trong thập ni&ecirc;n 70 v&agrave; 80. Họ t&igrave;m  thấy nhiều thứ được cho l&agrave; của d&atilde; nh&acirc;n - như l&ocirc;ng, ph&acirc;n, dấu ch&acirc;n v&agrave; chỗ  ở - song kh&ocirc;ng đưa ra kết luận ch&iacute;nh thức về sự tồn tại của ch&uacute;ng. Wang  khẳng định ba đo&agrave;n chuy&ecirc;n gia trước đ&acirc;y đ&atilde; phung ph&iacute; thời gian v&agrave; c&ocirc;ng  sức do t&igrave;m kiếm tr&ecirc;n phạm vi qu&aacute; rộng. Ngo&agrave;i ra thời đ&oacute; họ cũng kh&ocirc;ng c&oacute;  những thiết bị c&ocirc;ng nghệ ti&ecirc;n tiến. Cuộc t&igrave;m kiếm sắp tới sẽ chỉ tập  trung trong phạm vi hẹp, như c&aacute;c hang m&agrave; d&atilde; nh&acirc;n c&oacute; thể đang sống.</p>\n<p class="Normal">&ldquo;Ch&uacute;ng t&ocirc;i sẽ chia th&agrave;nh 5 đo&agrave;n để tập trung t&igrave;m kiếm  tại 5 khu vực quan trọng m&agrave; d&atilde; nh&acirc;n c&oacute; thể xuất hiện. C&aacute;c đo&agrave;n sẽ sử  dụng những biện ph&aacute;p hiện đại nhất, bao gồm cả bẫy ảnh. Với sự hỗ trợ  của c&aacute;c thiết bị hiện đại nhất, t&ocirc;i tin khả năng t&igrave;m thấy d&atilde; nh&acirc;n l&agrave; 80%  trở l&ecirc;n&rdquo;, Wang n&oacute;i.</p>\n<p class="Normal">Nhiều nh&agrave; khoa học tại Trung Quốc v&agrave; tr&ecirc;n thế giới cho  rằng, d&atilde; nh&acirc;n m&agrave; hơn 400 người từng thấy c&oacute; thể chỉ l&agrave; một lo&agrave;i đười  ươi m&agrave; con người chưa biết.</p>\n<p class="Normal">Nh&agrave; b&aacute;o Mỹ Nicholas Redfern, một trong những chuy&ecirc;n  gia về sinh vật lạ h&agrave;ng đầu thế giới, cho rằng nỗ lực của giới khoa học  Trung Quốc kh&ocirc;ng phải &yacute; tưởng viển v&ocirc;ng, bởi nhiều h&oacute;a thạch cho thấy d&atilde;  nh&acirc;n c&oacute; thể tồn tại.</p>\n<p class="Normal">&ldquo;Rất nhiều c&acirc;u chuyện về qu&aacute;i vật khổng lồ được người  d&acirc;n bịa ra dựa tr&ecirc;n những c&acirc;u chuyện cổ t&iacute;ch hoặc truyền thuyết. Nhưng  thật ra người ta đ&atilde; t&igrave;m thấy nhiều h&oacute;a thạch cho thấy những sinh vật lớn  giống người từng sống tại Trung Quốc hơn 300.000 năm trước&rdquo;, Redfern  n&oacute;i với <em>Fox News</em>.</p>\n<p class="Normal">C&aacute;c chuy&ecirc;n gia linh trưởng từng t&igrave;m thấy xương h&agrave;m,  răng v&agrave; nhiều mảnh xương kh&aacute;c của một động vật c&oacute; h&igrave;nh dạng giống người  trong rừng Thần N&ocirc;ng Gia. Sinh vật n&agrave;y c&oacute; chiều cao xấp xỉ 2,7 m. C&aacute;c  nh&agrave; khoa học gọi n&oacute; l&agrave; <em>Gigantopithecus</em>.</p>\n<p class="Normal">Redfern đ&atilde; tham gia v&ocirc; số cuộc t&igrave;m kiếm người rừng khổng lồ song c&aacute;c nỗ lực đ&oacute; đều thất bại v&igrave; thiếu tiền.</p>\n<p class="Normal">&ldquo;Chẳng c&oacute; g&igrave; tuyệt vời hơn nếu c&aacute;c nh&agrave; khoa học c&oacute; đủ  tiền để t&igrave;m kiếm sinh vật b&iacute; ẩn trong một năm. Nếu bạn chỉ v&agrave;o rừng  trong một tuần v&agrave; t&igrave;m kiếm một c&aacute;ch ngẫu nhi&ecirc;n th&igrave; cơ hội t&igrave;m thấy người  khổng lồ sẽ rất mong manh&rdquo;, &ocirc;ng n&oacute;i.</p>\n<p class="Normal">Song nếu Hiệp hội T&igrave;m kiếm người rừng tỉnh Hồ Bắc  quy&ecirc;n đủ tiền để thực hiện cuộc t&igrave;m kiếm l&acirc;u d&agrave;i th&igrave; một c&acirc;u hỏi đặt ra:  Người khổng lồ c&ograve;n sống trong c&aacute;c khu rừng ch&acirc;u &Aacute; kh&ocirc;ng?</p>\n<p class="Normal">&ldquo;C&aacute;c bằng chứng khoa học cho thấy <em>Gigantopithecus </em>đ&atilde;  tuyệt chủng từ l&acirc;u, nhưng c&aacute;c nh&agrave; khoa học cũng thường xuy&ecirc;n mắc sai  lầm. Kết luận cuối c&ugrave;ng của c&aacute;c nh&agrave; khoa học kh&ocirc;ng phải bao giờ cũng  đ&uacute;ng&rdquo;, Redfern ph&aacute;t biểu.</p>\n<p class="Normal" style="text-align: right;"><strong>Minh Long</strong></p>', '2010-10-22 15:14:10', 'nclong', 29, 1),
(9, 'test', 'test', 'http://localhost/mycms/images/upload/1287645742_2a.jpg', 'test', '<p>test</p>', '2010-10-22 16:54:42', 'nclong', 0, 0),
(10, 'test', 'test', '', '', '', '2010-10-22 17:10:23', 'nclong', 0, 0),
(11, 'tong-cong-ty-giau-khi-vn', 'tổng cồng ty giầu khí VN', 'http://localhost/mycms/images/upload/1287647107_cuu1.jpg', 'helo', '<p>t&eacute;t thử c&aacute;i n&agrave;o</p>', '2010-11-16 01:03:35', 'admin', 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `datas`
--

CREATE TABLE IF NOT EXISTS `datas` (
  `id` bigint(20) NOT NULL auto_increment,
  `data` text,
  PRIMARY KEY  (`id`),
  FULLTEXT KEY `data` (`data`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC AUTO_INCREMENT=49 ;

--
-- Dumping data for table `datas`
--

INSERT INTO `datas` (`id`, `data`) VALUES
(0, 'a'),
(34, 'che ban dien tu che ban dien tu'),
(35, 'thiet ke mach dien cho cong ty a thiet ke mach dien cho cong ty a'),
(33, 'xay dung nha o xay dung nha o'),
(12, 'Dự án test web2 Dự án test websiteCần 500 ngườiChi tiết vui lòng liên hệ số : 0973862100Thanks! du an test web2 du an test websitecan 500 nguoichi tiet vui long lien he so : 0973862100thanks!'),
(30, 'do hoa may tinh day them do hoa may tinh, gia hap dan'),
(32, 'du an xay dung duong bo ok, xay dung tuyen duong xyz'),
(31, 'phan mem ke toan xay dung phan mem ke toan cho cong ty abc'),
(36, 'xay nha dan dung xin chao tat ca moi nguoi, toi dang tim kiem mot doi tac hay doi tac cua tai nang. silhouetting kiem soat trong photoshop (voi clip con duong, mat na, lop ...). neu ban la mot vi vua cua thats chinh sua va hieu chinh mau sac tot hon. ban phai tuong doi co san, nhu cong viec trong tuong lai khong the du bao truoc va phai duoc thuc hien nhanh chong. toi thuc su exigeant. xin vui long them cac vi du ve nang luc cua ban!'),
(37, 'thiet ke banner flash helo'),
(38, 'thiet ke banner b dep, bat mat'),
(39, 'thiet ke banner a chung toi dang tim kiem mot nha thiet ke tai nang cho thiet ke lai mot trang web (khong phai tong so tu dau chi de thay doi no), chung ta can cac trang truoc va thiet ke lai trang ben trong. chung ta can ket qua theo dinh dang psd trong lop. co 3 du an khac nhau de lam gi sau khi lan dau tien mot'),
(40, 'du an kien truc b xay nha la mot chuyen lon cua doi nguoi,  co nhieu viec phai lam de co mot cong trinh nha o nhu y, lam sao de ban  thiet ke kien truc va ngoi nha cua ban dat day du cac tinh chat: tien  dung, tham my, kinh te va ben vung. voi goi y cua ahdesign giup cac ban  bot di cac kho khan ban dau.'),
(41, 'du an kien truc a xay nha la mot chuyen lon cua doi nguoi,  co nhieu viec phai lam de co mot cong trinh nha o nhu y, lam sao de ban  thiet ke kien truc va ngoi nha cua ban dat day du cac tinh chat: tien  dung, tham my, kinh te va ben vung. voi goi y cua ahdesign giup cac ban  bot di cac kho khan ban dau.'),
(21, 'Dự án cơ khí B Đây là các  dự án đã được Hội đồng Chính phủ thẩm tra phê duyệt đầu tư bằng nguồn  vốn vay ưu đãi đặc biệt. Tuy nhiên, cho đến nay dự án nầy hầu hết vẫn  đang án binh bất động.\nSau khi lựa chọn, Ban dự án cơ khí  trọng điểm đã quyết định đưa 24 dự án vào danh mục những Dự án cơ khí  trọng điểm. Theo đó, những dự án này được hưởng ưu đãi đặc biệt của Nhà  nước theo Quyết định 186/TTgcủa Thủ tướng Chính phủ và được vay thông  qua nguồn vốn từ Quỹ Hỗ trợ Phát triển (HTPT) với lãi suất 3%/năm trong  vòng 12 năm (hai năm đầu không phải trả lãi, trả nợ gốc bắt đầu từ năm  thứ 5). Có thể nói, sau gần 1 năm thực hiện một số dự án đầu tiên được  phê duyệt, 5 dự án được hoàn thiện để xin cơ chế ưu đãi. Tuy nhiên, cho  đến nay tất cả các dự án này đều bị ách tắc có nguy cơ phá sản do bị  vướng từ Nghị định 106/2004/CPngày 1/4/2004 cuả Chính phủ về tín dụng  đầu tư phát triển của nhà nước. du an co khi b day la cac  du an da duoc hoi dong chinh phu tham tra phe duyet dau tu bang nguon  von vay uu dai dac biet. tuy nhien, cho den nay du an nay hau het van  dang an binh bat dong.\nsau khi lua chon, ban du an co khi  trong diem da quyet dinh dua 24 du an vao danh muc nhung du an co khi  trong diem. theo do, nhung du an nay duoc huong uu dai dac biet cua nha  nuoc theo quyet dinh 186/ttgcua thu tuong chinh phu va duoc vay thong  qua nguon von tu quy ho tro phat trien (htpt) voi lai suat 3%/nam trong  vong 12 nam (hai nam dau khong phai tra lai, tra no goc bat dau tu nam  thu 5). co the noi, sau gan 1 nam thuc hien mot so du an dau tien duoc  phe duyet, 5 du an duoc hoan thien de xin co che uu dai. tuy nhien, cho  den nay tat ca cac du an nay deu bi ach tac co nguy co pha san do bi  vuong tu nghi dinh 106/2004/cpngay 1/4/2004 cua chinh phu ve tin dung  dau tu phat trien cua nha nuoc.'),
(42, 'du an co khi a day la cac  du an da duoc hoi dong chinh phu tham tra phe duyet dau tu bang nguon  von vay uu dai dac biet. tuy nhien, cho den nay du an nay hau het van  dang an binh bat dong.\nsau khi lua chon, ban du an co khi  trong diem da quyet dinh dua 24 du an vao danh muc nhung du an co khi  trong diem. theo do, nhung du an nay duoc huong uu dai dac biet cua nha  nuoc theo quyet dinh 186/ttgcua thu tuong chinh phu va duoc vay thong  qua nguon von tu quy ho tro phat trien (htpt) voi lai suat 3%/nam trong  vong 12 nam (hai nam dau khong phai tra lai, tra no goc bat dau tu nam  thu 5). co the noi, sau gan 1 nam thuc hien mot so du an dau tien duoc  phe duyet, 5 du an duoc hoan thien de xin co che uu dai. tuy nhien, cho  den nay tat ca cac du an nay deu bi ach tac co nguy co pha san do bi  vuong tu nghi dinh 106/2004/cpngay 1/4/2004 cua chinh phu ve tin dung  dau tu phat trien cua nha nuoc.'),
(43, 'du an website test ok lii'),
(44, 'thiet ke website mua ban kinh nghiem 3 nam thiet ke web'),
(45, 'du an long ca nha van can thiet cho mot du an. ban se duoc thanh toan theo chieu dai cua bai viet. ngoai ra, ban nen co the giao tiep it nhat 2 gio moi ngay. (thu hai-thu bay). xin vui long pm cho biet them chi tiet.'),
(48, 'du an vietnam idol truoc gio cong bo ket qua, 3 co gai tre da duoc tro ve nha, ve truong cu  va duoc moi nguoi don tiep rat nong hau. "dan chi" uyen linh tro ve  truong ptth le hong phong, tphcm da duoc cac dan em chao don nhu co da  la than tuong am nhac. leu phuong anh, mai huong bay ra ha noi&nbsp;gap lai  gia dinh, thay co, ban be...'),
(46, 'ggg tet'),
(47, 'ddd dddd');

-- --------------------------------------------------------

--
-- Table structure for table `duanmarks`
--

CREATE TABLE IF NOT EXISTS `duanmarks` (
  `id` bigint(20) NOT NULL auto_increment,
  `account_id` bigint(20) default NULL,
  `duan_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_duanmarks_accounts` (`account_id`),
  KEY `FK_duanmarks_duans` (`duan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=35 ;

--
-- Dumping data for table `duanmarks`
--


-- --------------------------------------------------------

--
-- Table structure for table `duans`
--

CREATE TABLE IF NOT EXISTS `duans` (
  `id` bigint(20) NOT NULL auto_increment,
  `tenduan` varchar(255) character set utf8 default NULL,
  `alias` varchar(255) character set utf8 default NULL,
  `linhvuc_id` varchar(100) character set utf8 default NULL,
  `tinh_id` bigint(20) default NULL,
  `ngayketthuc` datetime default NULL,
  `costmin` bigint(20) default NULL,
  `costmax` bigint(20) default NULL,
  `thongtinchitiet` text character set utf8,
  `file_id` bigint(20) default NULL,
  `ngaypost` datetime default NULL,
  `account_id` bigint(20) default NULL,
  `timeupdate` datetime default NULL,
  `prior` int(11) default NULL,
  `views` int(11) default NULL,
  `bidcount` int(11) default NULL,
  `averagecost` bigint(20) default NULL,
  `lastbid_nhathau` bigint(20) default NULL,
  `hosothau_id` bigint(20) default NULL,
  `nhathau_id` bigint(20) default NULL,
  `data_id` bigint(20) default NULL,
  `isnew` tinyint(1) default '1',
  `isbid` tinyint(1) default NULL,
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_duans_accounts` (`account_id`),
  KEY `FK_duans_files` (`file_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `duans`
--

INSERT INTO `duans` (`id`, `tenduan`, `alias`, `linhvuc_id`, `tinh_id`, `ngayketthuc`, `costmin`, `costmax`, `thongtinchitiet`, `file_id`, `ngaypost`, `account_id`, `timeupdate`, `prior`, `views`, `bidcount`, `averagecost`, `lastbid_nhathau`, `hosothau_id`, `nhathau_id`, `data_id`, `isnew`, `isbid`, `active`) VALUES
(22, 'Dự án Vietnam Idol', 'du-an-vietnam-idol', 'khac', 1, '2010-12-31 00:00:00', 100000, 500000, '<p>Trước giờ công bố kết quả, 3 cô gái trẻ đã được trở về nhà, về trường cũ  và được mọi người đón tiếp rất nồng hậu. "Đàn chị" Uyên Linh trở về  trường PTTH Lê Hồng Phong, TPHCM đã được các đàn em chào đón như cô đã  là thần tượng âm nhạc. Lều Phương Anh, Mai Hương bay ra Hà Nội&nbsp;gặp lại  gia đình, thầy cô, bạn bè...</p>', 9, '2010-12-15 00:39:21', 1, '2010-12-27 23:56:09', 0, 56, 0, 0, NULL, NULL, NULL, 48, 0, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `duanskills`
--

CREATE TABLE IF NOT EXISTS `duanskills` (
  `id` bigint(20) NOT NULL auto_increment,
  `duan_id` bigint(20) default NULL,
  `skill_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_duanskills_skills` (`skill_id`),
  KEY `FK_duanskills_duan` (`duan_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=132 ;

--
-- Dumping data for table `duanskills`
--

INSERT INTO `duanskills` (`id`, `duan_id`, `skill_id`) VALUES
(123, 22, 312),
(124, 22, 314),
(125, 22, 315),
(126, 22, 316),
(127, 22, 325),
(128, 22, 327),
(129, 22, 273),
(130, 22, 275),
(131, 22, 280);

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE IF NOT EXISTS `files` (
  `id` bigint(20) NOT NULL auto_increment,
  `filename` varchar(255) character set utf8 default NULL,
  `fileurl` varchar(255) default NULL,
  `account_id` bigint(20) default NULL,
  `account_share` bigint(20) default NULL,
  `status` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=77 ;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `filename`, `fileurl`, `account_id`, `account_share`, `status`) VALUES
(9, 'CQ_Tieu_chuan_dang_ky_lam_KLTN_K2006_2007.pdf', 'http://localhost/mycms/upload/files/1290786524_CQ_Tieu_chuan_dang_ky_lam_KLTN_K2006_2007.pdf', 1, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `hosothaus`
--

CREATE TABLE IF NOT EXISTS `hosothaus` (
  `id` bigint(20) NOT NULL auto_increment,
  `giathau` bigint(20) default NULL,
  `milestone` int(11) default NULL,
  `thoigian` int(11) default NULL,
  `content` text character set utf8,
  `ngaygui` datetime default NULL,
  `nhathau_id` bigint(20) default NULL,
  `duan_id` bigint(20) default NULL,
  `trangthai` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_bids_duans` (`duan_id`),
  KEY `FK_hosothaus_nhathaus` (`nhathau_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=26 ;

--
-- Dumping data for table `hosothaus`
--


-- --------------------------------------------------------

--
-- Table structure for table `images`
--

CREATE TABLE IF NOT EXISTS `images` (
  `id` bigint(20) NOT NULL auto_increment,
  `filename` varchar(50) default NULL,
  `fileurl` varchar(500) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `images`
--

INSERT INTO `images` (`id`, `filename`, `fileurl`) VALUES
(1, '1287474677_e2nz.png', 'http://www.jobbid.vn/images/upload/1287474677_e2nz.png'),
(2, '1287544883_Fire_Dragon_Icon.jpg', 'http://www.jobbid.vn/images/upload/1287544883_Fire_Dragon_Icon.jpg'),
(3, '1287544890_arrow.jpg', 'http://www.jobbid.vn/images/upload/1287544890_arrow.jpg'),
(4, '1287544897_active.png', 'http://www.jobbid.vn/images/upload/1287544897_active.png'),
(5, '1287544904_ActiveSync_icon_by_alex3305.png', 'http://www.jobbid.vn/images/upload/1287544904_ActiveSync_icon_by_alex3305.png'),
(6, '1287563610_excel.png', 'http://www.jobbid.vn/images/upload/1287563610_excel.png'),
(7, '1287632806_banner.jpg', 'http://www.jobbid.vn/images/upload/1287632806_banner.jpg'),
(8, '1287644796_2[3].jpg', 'http://www.jobbid.vn/images/upload/1287644796_2[3].jpg'),
(9, '1287645605_b2.jpg', 'http://www.jobbid.vn/images/upload/1287645605_b2.jpg'),
(10, '1287645742_2a.jpg', 'http://www.jobbid.vn/images/upload/1287645742_2a.jpg'),
(11, '1287645821_sub.jpg', 'http://www.jobbid.vn/images/upload/1287645821_sub.jpg'),
(12, '1287646690_mes2.jpg', 'http://www.jobbid.vn/images/upload/1287646690_mes2.jpg'),
(13, '1287647107_cuu1.jpg', 'http://www.jobbid.vn/images/upload/1287647107_cuu1.jpg'),
(14, '1287647165_yk2.jpg', 'http://www.jobbid.vn/images/upload/1287647165_yk2.jpg'),
(15, '1287712085_Older_IBM_Logo_2.png', 'http://www.jobbid.vn/images/upload/1287712085_Older_IBM_Logo_2.png'),
(16, '1290442295_Koala.jpg', 'http://www.jobbid.vn/images/upload/1290442295_Koala.jpg'),
(17, '1290442340_Lighthouse.jpg', 'http://www.jobbid.vn/images/upload/1290442340_Lighthouse.jpg'),
(18, '1293468584_banner.jpg', 'http://www.jobbid.vn/upload/images/1293468584_banner.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `linhvucs`
--

CREATE TABLE IF NOT EXISTS `linhvucs` (
  `id` varchar(100) character set ascii NOT NULL,
  `tenlinhvuc` varchar(100) default NULL,
  `soduan` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `linhvucs`
--

INSERT INTO `linhvucs` (`id`, `tenlinhvuc`, `soduan`) VALUES
('business-accounting-human', 'Buôn bán, Kế toán, Nhân sự', 0),
('cntt', 'Websites, IT & Software', 0),
('design-media-architect', 'Thiết kế, truyền thông, kiến trúc', 0),
('khac', 'Khác', 1),
('mobile', 'Mobile Phone', 0),
('nhaplieu-quantri', 'Nhập liệu, Quản trị', 0),
('sales-marketing', 'Sales & Marketing', 0),
('vietbai-danhmay-bientap', 'Viết bài, đánh máy, biên tập...', 0);

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE IF NOT EXISTS `menus` (
  `id` varchar(50) NOT NULL,
  `name` varchar(50) default NULL,
  `url` varchar(500) default NULL,
  `order` int(11) default NULL,
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `url`, `order`, `active`) VALUES
('home', 'Trang Chủ', 'http://www.jobbid.vn', 1, 1),
('login', 'Đăng Nhập', 'http://localhost/mycms/account/login', 6, 0),
('news', 'Tin Tức', 'http://www.jobbid.vn/article/news', 5, 1),
('page3', 'Page3', 'http://localhost/mycms/page/view/3/doc-suc-lo-cho-mien-trung-ruot-thit-', 4, 0),
('register', 'Đăng Ký', 'http://localhost/mycms/account/register', 7, 0),
('tao-du-an', 'Tạo Dự Án', 'http://www.jobbid.vn/duan/add', 2, 1),
('tim-du-an', 'Tìm Dự Án', 'http://www.jobbid.vn/duan/search', 3, 1),
('tro-giup', 'Trợ Giúp', 'http://www.jobbid.vn/webmaster/help', 6, 1);

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `id` bigint(20) NOT NULL auto_increment,
  `thongdiep` text character set utf8,
  `time` datetime default NULL,
  `account_id` bigint(20) default NULL,
  `duan_id` bigint(20) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `messages`
--


-- --------------------------------------------------------

--
-- Table structure for table `nhathaulinhvucs`
--

CREATE TABLE IF NOT EXISTS `nhathaulinhvucs` (
  `id` bigint(20) NOT NULL auto_increment,
  `nhathau_id` bigint(20) default NULL,
  `linhvuc_id` varchar(100) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_nhathaulinhvucs_nhathaus` (`nhathau_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=151 ;

--
-- Dumping data for table `nhathaulinhvucs`
--

INSERT INTO `nhathaulinhvucs` (`id`, `nhathau_id`, `linhvuc_id`) VALUES
(91, NULL, 'cntt'),
(92, NULL, 'design'),
(93, NULL, 'cntt'),
(94, NULL, 'design'),
(95, NULL, 'cntt'),
(96, NULL, 'design');

-- --------------------------------------------------------

--
-- Table structure for table `nhathaus`
--

CREATE TABLE IF NOT EXISTS `nhathaus` (
  `id` bigint(20) NOT NULL auto_increment,
  `displayname` varchar(255) character set utf8 default NULL,
  `motachitiet` text character set utf8,
  `gpkd_cmnd` varchar(100) character set utf8 default NULL,
  `birthyear` int(11) default NULL,
  `diachilienhe` varchar(255) character set utf8 default NULL,
  `file_id` bigint(20) default NULL,
  `account_id` bigint(20) default NULL,
  `diemdanhgia` int(11) default NULL,
  `nhanemail` tinyint(1) default NULL,
  `income` bigint(20) default NULL,
  `type` int(11) default NULL,
  `status` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_hosonhathaus_files` (`file_id`),
  KEY `FK_nhathaus_accounts` (`account_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=25 ;

--
-- Dumping data for table `nhathaus`
--


-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE IF NOT EXISTS `pages` (
  `id` bigint(20) NOT NULL auto_increment,
  `alias` varchar(255) default NULL,
  `title` varchar(255) default NULL,
  `content` text,
  `datemodified` datetime default NULL,
  `usermodified` varchar(100) default NULL,
  `menu_id` varchar(50) default '0',
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`id`, `alias`, `title`, `content`, `datemodified`, `usermodified`, `menu_id`, `active`) VALUES
(1, 'products-12', 'Products 12', '<p><span style="color: #ff0000;"><strong>San pham test<br /></strong></span></p>', '2010-10-22 22:14:17', 'admin', 'page2', 1),
(2, 'trang-dem-cho-tim-xac-nguoi-than', 'Trắng đêm chờ  tìm xác người thân', '<p class="Lead">"Thợ lặn b&aacute;o t&igrave;m được chiếc xe, t&ocirc;i chạy vội ra thắp  hương cầu khấn. Cả đ&ecirc;m kh&ocirc;ng t&agrave;i n&agrave;o ngủ được, đ&agrave;nh ra bờ s&ocirc;ng cầu mong  cho x&aacute;c chị c&ograve;n nằm trong đ&oacute;", th&acirc;n nh&acirc;n của chị Phạm Thị C&uacute;c v&agrave; b&eacute; g&aacute;i 7  th&aacute;ng tuổi tr&ecirc;n chuyến xe định mệnh n&oacute;i. <br />&gt;<a class="Lead" href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21D05/">Tiếng k&ecirc;u cứu tuyệt vọng tr&ecirc;n chiếc xe bị lũ cuốn</a>/ <a class="Lead" href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21E3B/">T&igrave;m thấy xe kh&aacute;ch bị lũ cuốn tr&ocirc;i</a></p>\n<p class="Normal">24h đ&ecirc;m, ngồi bần thần tr&ecirc;n quốc lộ 1A nh&igrave;n ra hai  chiếc t&agrave;u đang neo giữ chiếc xe kh&aacute;ch dưới l&ograve;ng s&ocirc;ng Lam đang chảy xiết,  chị Ho&agrave;ng Thị B&iacute;ch Hồng n&oacute;i như muốn kh&oacute;c: "Thợ lặn b&aacute;o đ&atilde; t&igrave;m được  chiếc xe, t&ocirc;i chạy ngay ra bờ s&ocirc;ng thắp hương cầu khấn. Cả đ&ecirc;m kh&ocirc;ng t&agrave;i  n&agrave;o ngủ được, đ&agrave;nh ra bờ s&ocirc;ng cầu mong cho x&aacute;c chị c&ograve;n nằm trong đ&oacute;".</p>\n<table border="0" cellspacing="0" cellpadding="3" width="268" align="center" bgcolor="#ddddff">\n<tbody>\n<tr>\n<td>*<em>Clip</em> <a href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21E6A/page_2.asp"><strong>Cứu hộ xe kh&aacute;ch tr&ecirc;n s&ocirc;ng Lam</strong></a></td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Chị Hồng l&agrave; người nh&agrave; của nạn nh&acirc;n Phạm Thị C&uacute;c v&agrave; b&eacute;  g&aacute;i 7 th&aacute;ng tuổi ở Đăk Lăk. Nghe tin hai mẹ con bị nạn tr&ecirc;n đường về  thăm qu&ecirc; Nam Định, cả đại gia đ&igrave;nh chị ngất l&ecirc;n ngất xuống, b&agrave; mẹ gi&agrave;  lịm dần phải v&agrave;o viện cấp cứu c&ograve;n chồng chị C&uacute;c cứ ngơ ngơ, ngẩn ngẩn&hellip;</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6A/IMG_0940a.jpg" alt="" width="495" height="358" /></td>\n</tr>\n<tr>\n<td class="Image">Chị Hồng đau đ&aacute;u nh&igrave;n về s&ocirc;ng Lam, nơi đ&oacute; c&oacute; người chị vừa đứa ch&aacute;u g&aacute;i 7 th&aacute;ng tuổi của chị.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Vượt mưa lũ từ Nam Định v&agrave;o Nghi Xu&acirc;n (H&agrave; Tĩnh), 3 đ&ecirc;m  liền chị Hồng ra bờ s&ocirc;ng ng&oacute;ng tr&ocirc;ng tin tức người chị xấu số. Mỗi khi  nghe một &acirc;m thanh lạ như tiếng c&ograve;i h&uacute; của cảnh s&aacute;t, xe cấp cứu&hellip;, &aacute;nh mắt  chị lại thấp thỏm chờ mong.</p>\n<p class="Normal">Chiều 20/10, khi người thợ lặn ngoi l&ecirc;n bờ khẳng định  đ&atilde; t&igrave;m được chiếc xe bị tr&ocirc;i, chị đ&atilde; &ocirc;m chầm lấy th&acirc;n nh&acirc;n c&aacute;c nạn nh&acirc;n.  Cả đ&ecirc;m qua kh&ocirc;ng ngủ được, chị lại ra bờ s&ocirc;ng cầu khấn hy vọng cho x&aacute;c  sẽ c&ograve;n ở trong xe v&agrave; qu&aacute; tr&igrave;nh trục vớt diễn ra an to&agrave;n.</p>\n<p class="Normal">Kế hoạch trục vớt chiếc xe ngay trong đ&ecirc;m bị hủy bỏ v&igrave;  s&oacute;ng to, gi&oacute; lớn v&agrave; nước s&acirc;u, một số th&acirc;n nh&acirc;n l&ecirc;n &ocirc;t&ocirc; về ph&ograve;ng nghỉ  lấy sức chờ ng&agrave;y mai, một số thức trắng tr&ecirc;n bờ s&ocirc;ng để cầu nguyện.</p>\n<p class="Normal">C&ugrave;ng chung t&acirc;m trạng như chị Hồng, anh Nguyễn Văn Th&acirc;n  ở Thanh H&oacute;a, ch&uacute; ruột của hai chị em Đỗ Thị Phượng (17 tuổi), Đỗ Thị  Lan (15 tuổi) tr&ecirc;n chuyến xe định mệnh cũng chỉ hy vọng sẽ c&ograve;n x&aacute;c của  ch&aacute;u g&aacute;i m&igrave;nh trong xe.</p>\n<p class="Normal">&ldquo;Hai chị em n&oacute; khổ lắm, học hết lớp 6 đ&atilde; phải bỏ học  đi T&acirc;y Nguy&ecirc;n trồng c&agrave; ph&ecirc;, nay hai đứa về để ăn cưới người d&igrave; ruột. Ai  ngờ mọi người lại phải lo đ&aacute;m tang chung cho hai đứa. Cha mẹ n&oacute; ngất xỉu  khi nghe tin con bị chết chưa t&igrave;m thấy x&aacute;c&rdquo;, anh Th&acirc;n n&oacute;i trong nước  mắt.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/6A/IMG_0945a.jpg" alt="" width="495" height="362" /></td>\n</tr>\n<tr>\n<td class="Image">Anh Th&acirc;n thức trắng đ&ecirc;m b&ecirc;n bờ s&ocirc;ng Lam.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Đ&ecirc;m qua, cả chị Hồng v&agrave; anh Th&acirc;n thẫn thờ nh&igrave;n ra biển  nước m&ecirc;nh m&ocirc;ng, thỉnh thoảng lại cầu trời mong cho đến s&aacute;ng. Ở kh&aacute;ch  sạn nơi những th&acirc;n nh&acirc;n đang nghỉ ngơi, những người kh&aacute;c cũng chong đ&egrave;n  suốt đ&ecirc;m chờ trời s&aacute;ng v&agrave; cầu mong cho x&aacute;c của người th&acirc;n chưa tr&ocirc;i khỏi  xe&hellip;</p>\n<p class="Normal">Đ&ecirc;m qua, trăng s&aacute;ng vằng vặc, nước s&ocirc;ng Lam vẫn đỏ  ng&agrave;u, thỉnh thoảng tiếng s&oacute;ng nước vỗ v&agrave;o bờ k&egrave; lẫn với tiếng kh&oacute;c nức  nở của th&acirc;n nh&acirc;n nạn nh&acirc;n.</p>\n<p class="Normal">4h s&aacute;ng 18/10, xe kh&aacute;ch từ Đăk N&ocirc;ng ra Bắc đến x&atilde; Xu&acirc;n  Lam (Nghi Xu&acirc;n, H&agrave; Tĩnh) đ&atilde; bị lũ cuốn lật v&agrave; tr&ocirc;i xuống s&ocirc;ng Lam.  Nhiều h&agrave;nh kh&aacute;ch đ&atilde; đập cửa k&iacute;nh tho&aacute;t ra. Lực lượng cứu hộ v&agrave; người d&acirc;n  ch&egrave;o thuyền ra cứu được 18 người. 20 người c&ograve;n lại bị mất t&iacute;ch.</p>\n<p class="Normal" style="text-align: right;"><strong>Nguy&ecirc;n Khoa &ndash; Nguyễn Hưng</strong></p>', '2010-10-22 22:21:45', 'admin', 'page1', 1),
(3, 'doc-suc-lo-cho-mien-trung-ruot-thit', 'Dốc sức lo cho miền Trung ruột thịt', '<p class="Lead">11h trưa nay, xe kh&aacute;ch bị cuốn tr&ocirc;i tại Nghi Xu&acirc;n (H&agrave;  Tĩnh) đ&atilde; được t&agrave;u k&eacute;o l&ecirc;n v&agrave; đưa v&agrave;o bờ s&ocirc;ng Lam. Trước đ&oacute; 4 x&aacute;c h&agrave;nh  kh&aacute;ch đ&atilde; được t&igrave;m thấy.<br />* Tiếp tục cập nhật (độc giả nhấn F5).<br />&gt; <a class="Lead" href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21D05/">Tiếng k&ecirc;u cứu tuyệt vọng tr&ecirc;n chiếc xe bị lũ cuốn</a>/ <a class="Lead" href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21E3B/">T&igrave;m thấy xe kh&aacute;ch bị lũ cuốn tr&ocirc;i</a></p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/3B/a5.jpg" alt="" width="495" height="330" /></td>\n</tr>\n<tr>\n<td class="Image">C&aacute;c lực lượng tập kết tr&ecirc;n s&ocirc;ng Lam. Ảnh: <em>H&agrave; Khoa</em></td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Trong số nạn nh&acirc;n được t&igrave;m thấy, một người đ&atilde; x&aacute;c định  danh t&iacute;nh l&agrave; t&agrave;i xế Đinh Văn Lương. Anh n&agrave;y bị mắc ngay bụi c&acirc;y c&aacute;ch  địa điểm xe bị tr&ocirc;i v&agrave;i trăm m&eacute;t, tr&ecirc;n người c&ograve;n nguy&ecirc;n chiếc v&iacute; chứa  rất nhiều giấy tờ v&agrave; tiền bạc. Trong xe được cho l&agrave; c&oacute; 19 nạn nh&acirc;n.</p>\n<table border="1" cellspacing="0" cellpadding="3" width="307" align="center" bgcolor="#ffe1e1">\n<tbody>\n<tr>\n<td><em>Clip</em>:<strong><a href="http://vnexpress.net/GL/Xa-hoi/2010/10/3BA21E3B/page_2.asp"> Cứu hộ xe kh&aacute;ch tr&ecirc;n s&ocirc;ng Lam</a></strong></td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">Từ 6h30 lực lượng trực vớt khoảng 100 người gồm c&ocirc;ng  binh, bộ đội bi&ecirc;n ph&ograve;ng, c&ocirc;ng an v&agrave; lực lượng cứu hộ của 6 doanh nghiệp  đ&atilde; c&oacute; mặt. Ngo&agrave;i hai t&agrave;u k&eacute;o cỡ lớn, hai x&agrave; lan của doanh nghiệp, rất  nhiều cano t&igrave;m kiếm trước đ&oacute;, s&aacute;ng nay qu&acirc;n đội đ&atilde; huy động th&ecirc;m một t&agrave;u  đầu k&eacute;o cỡ lớn phục vụ cho việc trục vớt.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/3B/902.jpg" border="1" alt="" width="495" height="350" /></td>\n</tr>\n<tr>\n<td class="Image">Chuẩn bị trục vớt.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">9h, hai chiếc t&agrave;u, hai chiếc x&agrave; lan chia th&agrave;nh hai  nh&oacute;m c&ugrave;ng tiếp cận vị tr&iacute; chiếc xe. C&aacute;c thợ lặn ngậm v&ograve;i oxy v&agrave; mang  theo d&acirc;y c&aacute;p, sẵn s&agrave;ng nhảy xuống s&ocirc;ng. Theo kế hoạch, sau khi m&oacute;c d&acirc;y  c&aacute;p, t&agrave;u v&agrave; x&agrave; lan sẽ n&acirc;ng xe l&ecirc;n, để xe lội nước v&agrave; xe đầu k&eacute;o chuy&ecirc;n  dụng của qu&acirc;n đội k&eacute;o v&agrave;o bờ.</p>\n<p class="Normal">9h10, lực lượng cứu hộ vớt th&ecirc;m x&aacute;c một nạn nh&acirc;n l&agrave;  anh Đinh Xu&acirc;n Thường. Thi thể nạn nh&acirc;n được đưa v&agrave;o l&aacute;n tập kết, nơi c&oacute;  th&acirc;n nh&acirc;n đang chờ sẵn để nhận dạng.</p>\n<p class="Normal">9h15 hai thợ lăn ngoi l&ecirc;n mặt nước cho biết xe kh&aacute;ch  nằm ngang s&ocirc;ng, họ đ&atilde; m&oacute;c d&acirc;y c&aacute;p v&agrave;o xe để chuẩn bị k&eacute;o l&ecirc;n. Tr&ecirc;n hai  chiếc t&agrave;u, người nh&agrave; nạn nh&acirc;n đang l&agrave;m lễ theo phong tục địa phương.</p>\n<p class="Normal">9h50, hai thợ lặn ngoi l&ecirc;n mặt nước cho biết, việc  buộc c&aacute;p rất kh&oacute; khăn do nước xiết, xe nằm s&acirc;u. Tiện nhất l&agrave; buộc v&agrave;o  b&aacute;nh xe, nhưng cả 8 b&aacute;nh đều bị v&ugrave;i s&acirc;u trong c&aacute;t. Lực lượng trục vớt  lại hội &yacute; để b&agrave;n c&aacute;ch buộc d&acirc;y c&aacute;p kh&aacute;c.</p>\n<p class="Normal">Khoảng 10 ph&uacute;t sau, thợ lặn th&ocirc;ng b&aacute;o đ&atilde; buộc được c&aacute;p v&agrave;o b&aacute;nh xe, chuẩn bị n&acirc;ng xe l&ecirc;n khỏi vị tr&iacute;.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/3B/lan.jpg" alt="" width="495" height="353" /></td>\n</tr>\n<tr>\n<td class="Image">Thợ lặn đang m&oacute;c d&acirc;y c&aacute;p v&agrave;o xe kh&aacute;ch gặp nạn.</td>\n</tr>\n</tbody>\n</table>\n<p class="Normal">10h30, lực lượng cứu hộ nhận được điện thoại của ngư  d&acirc;n b&aacute;o ph&aacute;t hiện một thi thể tr&ecirc;n s&ocirc;ng Lam đoạn qua phường Bến Thủy,  th&agrave;nh phố Vinh (Nghệ An), c&aacute;ch nơi vị tr&iacute; xe tai nạn khoảng 10 km. Ngư  d&acirc;n đ&atilde; neo x&aacute;c lại để chờ cơ quan chức năng đến giải quyết.</p>\n<p class="Normal">Dọc bờ s&ocirc;ng Lam, khoảng 10 xuồng cao tốc của c&ocirc;ng an,  bộ đội, bi&ecirc;n ph&ograve;ng li&ecirc;n tục tuần tiễu quanh vị tr&iacute; xe gặp nạn để hỗ trợ.  Một số người d&acirc;n ch&egrave;o thuyền nan ra sẵn s&agrave;ng gi&uacute;p đỡ khi cần thiết.</p>\n<p class="Normal">Quốc lộ 1A bị phong tỏa khoảng một km. Tuy nhi&ecirc;n, h&agrave;ng ngh&igrave;n người d&acirc;n đ&atilde; đi v&ograve;ng l&ecirc;n n&uacute;i để chứng kiến.</p>\n<table border="0" cellspacing="0" cellpadding="3" width="1" align="center">\n<tbody>\n<tr>\n<td><img src="http://vnexpress.net/Files/Subject/3B/A2/1E/3B/900.jpg" border="1" alt="" width="495" height="350" /></td>\n</tr>\n<tr>\n<td class="Image">H&agrave;ng ngh&igrave;n người đứng tr&ecirc;n n&uacute;i theo d&otilde;i trục vớt.</td>\n</tr>\n</tbody>\n</table>\n<p class="normal">Tỉnh H&agrave; Tĩnh cho biết sẽ hỗ trợ to&agrave;n bộ kinh ph&iacute; kh&acirc;m  liệm, gi&aacute;m định ph&aacute;p y, vệ sinh y tế, chuẩn bị xe đưa thi thể nạn nh&acirc;n  về qu&ecirc;. Mỗi gia đ&igrave;nh được hỗ trợ 6 triệu đồng.</p>\n<p class="Normal">Chiều tối 20/10, sau nhiều giờ lặn khảo s&aacute;t v&agrave; neo c&aacute;p  cố định chiếc xe kh&aacute;ch dưới l&ograve;ng s&ocirc;ng, lực lượng cứu hộ quyết định chờ  tới s&aacute;ng nay mới tiến h&agrave;nh trục vớt.</p>\n<p class="Normal" style="text-align: right;"><strong>Nguyễn Hưng - Nguy&ecirc;n Khoa</strong></p>\n<p>﻿</p>', '2010-10-22 17:30:42', 'nclong', 'page3', 1),
(10, 'test', 'test', '<p>test</p>', '2010-10-22 22:14:46', 'admin', '0', 0);

-- --------------------------------------------------------

--
-- Table structure for table `resetpasswords`
--

CREATE TABLE IF NOT EXISTS `resetpasswords` (
  `id` bigint(20) NOT NULL auto_increment,
  `account_id` bigint(20) default NULL,
  `times` int(11) default NULL,
  `verify` varchar(20) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_resetpasswords_accounts` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `resetpasswords`
--


-- --------------------------------------------------------

--
-- Table structure for table `sendmails`
--

CREATE TABLE IF NOT EXISTS `sendmails` (
  `id` bigint(20) NOT NULL auto_increment,
  `to` varchar(100) default NULL,
  `subject` varchar(255) default NULL,
  `content` text,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `sendmails`
--


-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE IF NOT EXISTS `skills` (
  `id` bigint(20) NOT NULL auto_increment,
  `skillname` varchar(100) character set utf8 default NULL,
  `linhvuc_id` varchar(100) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=337 ;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `skillname`, `linhvuc_id`) VALUES
(1, 'AJAX', 'cntt'),
(3, 'Java Script', 'cntt'),
(6, 'HTML', 'cntt'),
(20, 'Active Directory', 'cntt'),
(21, 'Amazon Web Services', 'cntt'),
(22, 'Apache', 'cntt'),
(23, 'ASP', 'cntt'),
(24, 'AutoHotkey', 'cntt'),
(25, 'Azure', 'cntt'),
(26, 'Balsamiq', 'cntt'),
(27, 'Blog Install', 'cntt'),
(28, 'BMC Remedy', 'cntt'),
(29, 'Boonex Dolphin', 'cntt'),
(30, 'Business Catalyst', 'cntt'),
(31, 'C# Programming', 'cntt'),
(32, 'C++ Programming', 'cntt'),
(33, 'CakePHP', 'cntt'),
(34, 'Chordiant', 'cntt'),
(35, 'Chrome OS', 'cntt'),
(36, 'Cisco', 'cntt'),
(37, 'Cloud Computing', 'cntt'),
(38, 'CMS', 'cntt'),
(39, 'COBOL', 'cntt'),
(40, 'Cocoa', 'cntt'),
(41, 'Codeigniter', 'cntt'),
(42, 'Cold Fusion', 'cntt'),
(43, 'Computer Security', 'cntt'),
(44, 'CRE Loaded', 'cntt'),
(45, 'CubeCart', 'cntt'),
(46, 'CUDA', 'cntt'),
(47, 'Delphi', 'cntt'),
(48, 'Django', 'cntt'),
(49, 'DNS', 'cntt'),
(50, 'DotNetNuke', 'cntt'),
(51, 'Drupal', 'cntt'),
(52, 'eCommerce', 'cntt'),
(53, 'Electronic Forms', 'cntt'),
(54, 'Embedded Software', 'cntt'),
(55, 'Erlang', 'cntt'),
(56, 'Expression Engine', 'cntt'),
(57, 'Facebook', 'cntt'),
(58, 'FileMaker', 'cntt'),
(59, 'Firefox', 'cntt'),
(60, 'Fortran', 'cntt'),
(61, 'Forum Software', 'cntt'),
(62, 'Game Design', 'cntt'),
(63, 'Google Analytics', 'cntt'),
(64, 'Google App Engine', 'cntt'),
(65, 'Google Buzz', 'cntt'),
(66, 'Google Earth', 'cntt'),
(67, 'Google Go', 'cntt'),
(68, 'Google Wave', 'cntt'),
(69, 'GPGPU', 'cntt'),
(70, 'HP Openview', 'cntt'),
(71, 'HTML', 'cntt'),
(72, 'HTML5', 'cntt'),
(73, 'IBM Tivoli', 'cntt'),
(74, 'IIS', 'cntt'),
(75, 'J2EE', 'cntt'),
(76, 'Java', 'cntt'),
(77, 'JavaFX', 'cntt'),
(78, 'Javascript', 'cntt'),
(79, 'Joomla', 'cntt'),
(80, 'jQuery / Prototype', 'cntt'),
(81, 'JSP', 'cntt'),
(82, 'LabVIEW', 'cntt'),
(83, 'Link Building', 'cntt'),
(84, 'Linux', 'cntt'),
(85, 'Lotus Notes', 'cntt'),
(86, 'Mac OS', 'cntt'),
(87, 'Magento', 'cntt'),
(88, 'Metatrader', 'cntt'),
(89, 'Microsoft', 'cntt'),
(90, 'Microsoft Access', 'cntt'),
(91, 'Microsoft Exchange', 'cntt'),
(92, 'Microsoft Expression', 'cntt'),
(93, 'MMORPG', 'cntt'),
(94, 'MODx', 'cntt'),
(95, 'MySpace', 'cntt'),
(96, 'MySQL', 'cntt'),
(97, 'Nginx', 'cntt'),
(98, 'NoSQL Couch & Mongo', 'cntt'),
(99, 'Objective C', 'cntt'),
(100, 'Oracle', 'cntt'),
(101, 'OSCommerce', 'cntt'),
(102, 'Parallels Automation', 'cntt'),
(103, 'Parallels Desktop', 'cntt'),
(104, 'Paypal API', 'cntt'),
(105, 'Pentaho', 'cntt'),
(106, 'Perl', 'cntt'),
(107, 'Photoshop Coding', 'cntt'),
(108, 'PHP', 'cntt'),
(109, 'PICK Multivalue DB', 'cntt'),
(110, 'Plesk', 'cntt'),
(111, 'Prestashop', 'cntt'),
(112, 'Prolog', 'cntt'),
(113, 'Protoshare', 'cntt'),
(114, 'Python', 'cntt'),
(115, 'REALbasic', 'cntt'),
(116, 'Rocket Engine', 'cntt'),
(117, 'Ruby & Ruby on Rails', 'cntt'),
(118, 'SAP', 'cntt'),
(119, 'Script Install', 'cntt'),
(120, 'Sencha / YahooUI', 'cntt'),
(121, 'SEO', 'cntt'),
(122, 'Sharepoint', 'cntt'),
(123, 'Shell Script', 'cntt'),
(124, 'Shopping Carts', 'cntt'),
(125, 'Silverlight', 'cntt'),
(126, 'Social Engine', 'cntt'),
(127, 'Social Networking', 'cntt'),
(128, 'Software Architecture', 'cntt'),
(129, 'Software Testing', 'cntt'),
(130, 'Solaris', 'cntt'),
(131, 'SQL', 'cntt'),
(132, 'Symfony PHP', 'cntt'),
(133, 'System Admin', 'cntt'),
(134, 'TaoBao API', 'cntt'),
(135, 'Twitter', 'cntt'),
(136, 'UML Design', 'cntt'),
(137, 'UNIX', 'cntt'),
(138, 'Usability Testing', 'cntt'),
(139, 'User Interface / IA', 'cntt'),
(140, 'vBulletin', 'cntt'),
(141, 'Virtual Worlds', 'cntt'),
(142, 'Virtuemart', 'cntt'),
(143, 'Virtuozzo', 'cntt'),
(144, 'Visual Basic', 'cntt'),
(145, 'Visual Foxpro', 'cntt'),
(146, 'VoIP', 'cntt'),
(147, 'Volusion', 'cntt'),
(148, 'vTiger', 'cntt'),
(149, 'Web Scraping', 'cntt'),
(150, 'Web Security', 'cntt'),
(151, 'Website Testing', 'cntt'),
(152, 'Windows Desktop', 'cntt'),
(153, 'Windows Server', 'cntt'),
(154, 'Wordpress', 'cntt'),
(155, 'XML', 'cntt'),
(156, 'XSLT', 'cntt'),
(157, 'YouTube', 'cntt'),
(158, 'Zen Cart', 'cntt'),
(159, 'Zend', 'cntt'),
(160, 'Viết sách', 'vietbai-danhmay-bientap'),
(161, 'Biên tập', 'vietbai-danhmay-bientap'),
(162, 'Viết bài', 'vietbai-danhmay-bientap'),
(163, 'Viết tin tức', 'vietbai-danhmay-bientap'),
(164, 'Astroturfing', 'vietbai-danhmay-bientap'),
(165, 'Viết Blog', 'vietbai-danhmay-bientap'),
(166, 'Cartography & Maps', 'vietbai-danhmay-bientap'),
(167, 'Copywriting', 'vietbai-danhmay-bientap'),
(168, 'eBooks', 'vietbai-danhmay-bientap'),
(169, 'Biên tập', 'vietbai-danhmay-bientap'),
(170, 'Tiểu thuyết', 'vietbai-danhmay-bientap'),
(171, 'Nghiên cứu tài chính', 'vietbai-danhmay-bientap'),
(172, 'Post bài trên Forum', 'vietbai-danhmay-bientap'),
(173, 'Viết di chúc', 'vietbai-danhmay-bientap'),
(174, 'LaTeX', 'vietbai-danhmay-bientap'),
(175, 'PDF', 'vietbai-danhmay-bientap'),
(176, 'Powerpoint', 'vietbai-danhmay-bientap'),
(177, 'Viết quảng cáo', 'vietbai-danhmay-bientap'),
(178, 'Đọc và phát hiện lỗi', 'vietbai-danhmay-bientap'),
(179, 'Xuất bản', 'vietbai-danhmay-bientap'),
(180, 'Viết báo cáo', 'vietbai-danhmay-bientap'),
(181, 'Nghiên cứu', 'vietbai-danhmay-bientap'),
(182, 'Resumes', 'vietbai-danhmay-bientap'),
(183, 'Reviews', 'vietbai-danhmay-bientap'),
(184, 'Tốc ký', 'vietbai-danhmay-bientap'),
(185, 'Viết tài liệu', 'vietbai-danhmay-bientap'),
(186, 'Dịch thuật', 'vietbai-danhmay-bientap'),
(187, 'Travel Writing', 'vietbai-danhmay-bientap'),
(188, 'WIKI', 'vietbai-danhmay-bientap'),
(189, 'Kiến trúc sư', 'design-media-architect'),
(190, '3D Animation', 'design-media-architect'),
(191, '3D Modeling', 'design-media-architect'),
(192, '3D Rendering', 'design-media-architect'),
(193, '3ds Max', 'design-media-architect'),
(194, 'AutoCAD', 'design-media-architect'),
(195, 'ActionScript', 'design-media-architect'),
(196, 'Advertisement Design', 'design-media-architect'),
(197, 'After Effects', 'design-media-architect'),
(198, 'Animation', 'design-media-architect'),
(199, 'Arts & Crafts', 'design-media-architect'),
(200, 'Audio Services', 'design-media-architect'),
(201, 'Banner Design', 'design-media-architect'),
(202, 'Blog Design', 'design-media-architect'),
(203, 'Brochure Design', 'design-media-architect'),
(204, 'Building Architecture', 'design-media-architect'),
(205, 'Business Cards', 'design-media-architect'),
(206, 'Capture NX2', 'design-media-architect'),
(207, 'Caricature & Cartoons', 'design-media-architect'),
(208, 'Commercials', 'design-media-architect'),
(209, 'Concept Design', 'design-media-architect'),
(210, 'Corporate Identity', 'design-media-architect'),
(211, 'Covers & Packaging', 'design-media-architect'),
(212, 'CSS', 'design-media-architect'),
(213, 'Dreamweaver', 'design-media-architect'),
(214, 'Fashion Design', 'design-media-architect'),
(215, 'Final Cut Pro', 'design-media-architect'),
(216, 'Finale / Sibelius', 'design-media-architect'),
(217, 'Flash', 'design-media-architect'),
(218, 'Flex', 'design-media-architect'),
(219, 'Format & Layout', 'design-media-architect'),
(220, 'Google SketchUp', 'design-media-architect'),
(221, 'Graphic Design', 'design-media-architect'),
(222, 'Icon Design', 'design-media-architect'),
(223, 'Vẽ tranh minh họa', 'design-media-architect'),
(224, 'Mỹ thuật công nghiệp', 'design-media-architect'),
(225, 'Interior Design', 'design-media-architect'),
(226, 'Logo Design', 'design-media-architect'),
(227, 'Maya', 'design-media-architect'),
(228, 'Music', 'design-media-architect'),
(229, 'Papervision3D', 'design-media-architect'),
(230, 'Photo Editing', 'design-media-architect'),
(231, 'Photography', 'design-media-architect'),
(232, 'Photoshop', 'design-media-architect'),
(233, 'Photoshop Design', 'design-media-architect'),
(234, 'Print', 'design-media-architect'),
(235, 'PSD to HTML', 'design-media-architect'),
(236, 'PSD2CMS', 'design-media-architect'),
(237, ' QuarkXPress', 'design-media-architect'),
(238, 'Shopify Templates', 'design-media-architect'),
(239, 'Stationery Design', 'design-media-architect'),
(240, 'Templates', 'design-media-architect'),
(241, 'Typography', 'design-media-architect'),
(242, 'Video Broadcasting', 'design-media-architect'),
(243, 'Video Services', 'design-media-architect'),
(244, 'Lồng tiếng', 'design-media-architect'),
(245, 'Website Design', 'design-media-architect'),
(246, 'Đánh máy 10 ngón', 'nhaplieu-quantri'),
(247, 'Có kết nối Internet tại nhà', 'nhaplieu-quantri'),
(248, 'Có kết nối Internet tại nhà', 'nhaplieu-quantri'),
(249, 'Xử lý yêu cầu', 'nhaplieu-quantri'),
(250, 'Hỗ trợ khách hàng', 'nhaplieu-quantri'),
(251, 'Hỗ trợ điện thoại', 'nhaplieu-quantri'),
(252, 'Hỗ trợ kỹ thuật', 'nhaplieu-quantri'),
(253, 'Video Upload', 'nhaplieu-quantri'),
(254, 'Virtual Assistant', 'nhaplieu-quantri'),
(255, 'Web Search', 'nhaplieu-quantri'),
(256, 'Branding', 'sales-marketing'),
(257, 'Bulk Marketing', 'sales-marketing'),
(258, 'Classifieds Posting', 'sales-marketing'),
(259, 'CRM', 'sales-marketing'),
(260, 'eBay', 'sales-marketing'),
(261, 'Google Adsense', 'sales-marketing'),
(262, 'Internet Marketing', 'sales-marketing'),
(263, 'Leads', 'sales-marketing'),
(264, 'Market Research', 'sales-marketing'),
(265, 'Marketing', 'sales-marketing'),
(266, 'MLM', 'sales-marketing'),
(267, 'Sales', 'sales-marketing'),
(268, 'SEM / Adwords', 'sales-marketing'),
(269, 'Telemarketing', 'sales-marketing'),
(270, 'Kế toán', 'business-accounting-human'),
(271, 'Kiểm toán', 'business-accounting-human'),
(272, 'Kiểm toán', 'business-accounting-human'),
(273, 'Phân tích nghiệp vụ (BI)', 'business-accounting-human'),
(274, 'Lên kế hoạch kinh doanh', 'business-accounting-human'),
(275, 'Hợp đồng', 'business-accounting-human'),
(276, 'Luật lao động', 'business-accounting-human'),
(277, 'ERP', 'business-accounting-human'),
(278, 'Event Planning', 'business-accounting-human'),
(279, 'Tài chính', 'business-accounting-human'),
(280, 'Human Resources', 'business-accounting-human'),
(281, 'Inventory Management', 'business-accounting-human'),
(282, 'ISO9001', 'business-accounting-human'),
(283, 'Legal', 'business-accounting-human'),
(284, 'Legal Research', 'business-accounting-human'),
(285, 'Quản lý', 'business-accounting-human'),
(286, 'Patents', 'business-accounting-human'),
(287, 'Payroll', 'business-accounting-human'),
(288, 'PeopleSoft', 'business-accounting-human'),
(289, 'Trưởng dự án (PM)', 'business-accounting-human'),
(290, 'Property Law', 'business-accounting-human'),
(291, 'Public Relations', 'business-accounting-human'),
(292, 'Quickbooks & Quicken', 'business-accounting-human'),
(293, 'Salesforce.com', 'business-accounting-human'),
(294, 'SAS', 'business-accounting-human'),
(295, 'Tax', 'business-accounting-human'),
(296, 'Tax Law', 'business-accounting-human'),
(297, 'Visa / Immigration', 'business-accounting-human'),
(298, 'Amazon Kindle', 'mobile'),
(299, 'Android', 'mobile'),
(300, 'Blackberry', 'mobile'),
(301, 'Geolocation', 'mobile'),
(302, 'iPad', 'mobile'),
(303, 'iPhone', 'mobile'),
(304, 'J2ME', 'mobile'),
(305, 'Mobile Phone', 'mobile'),
(306, 'Nokia', 'mobile'),
(307, 'Palm', 'mobile'),
(308, 'Samsung', 'mobile'),
(309, 'Symbian', 'mobile'),
(310, 'Windows CE', 'mobile'),
(311, 'Windows Mobile', 'mobile'),
(312, 'Năng động, nhiệt tình', 'khac'),
(313, 'Giao tiếp tốt.', 'khac'),
(314, 'Anh Văn giao tiếp', 'khac'),
(315, 'Anh Văn đọc hiểu', 'khac'),
(316, 'Tốt nghiệp đại học', 'khac'),
(317, 'Tốt nghiệp cao đẳng', 'khac'),
(318, 'Tốt nghiệp trung cấp', 'khac'),
(319, 'Anything Goes', 'khac'),
(320, 'Automotive', 'khac'),
(321, 'Dating', 'khac'),
(322, 'Education & Tutoring', 'khac'),
(323, 'Financial Markets', 'khac'),
(324, 'Genealogy', 'khac'),
(325, 'Health', 'khac'),
(326, 'Insurance', 'khac'),
(327, 'Dinh dưỡng', 'khac'),
(328, 'Pattern Making', 'khac'),
(329, 'Psychology', 'khac'),
(330, 'Thể thao', 'khac'),
(331, 'Test Automation', 'khac'),
(332, 'Testing / QA', 'khac'),
(333, 'Training', 'khac'),
(334, 'Troubleshooting', 'khac'),
(335, 'Valuation & Appraisal', 'khac'),
(336, 'Weddings', 'khac');

-- --------------------------------------------------------

--
-- Table structure for table `tests`
--

CREATE TABLE IF NOT EXISTS `tests` (
  `test` text,
  FULLTEXT KEY `test` (`test`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 CHECKSUM=1 DELAY_KEY_WRITE=1 ROW_FORMAT=DYNAMIC;

--
-- Dumping data for table `tests`
--

INSERT INTO `tests` (`test`) VALUES
('MySQL 5.0\r\nTable default charset UTF8\r\nNgôn ngữ dữ liệu: Tiếng Việt\r\n\r\nTABLE ----------------------------\r\n\r\ncreate table exam(\r\nid int auto_increment primary key,\r\nname varchar(1000),\r\nfulltext key ''a'' (name)\r\n)Engine=MyISAM Charset=utf8;\r\n\r\nQUERY ------------------------------\r\n\r\n1. select name from exam where match(name) against(''nhân'');\r\n2. select name from exam where match(name) against(''nhan'');\r\n\r\nRESULT -----------------------------\r\n\r\nDòng 1 - Kết quả ra luôn cả những dòng dữ liệu là "nhận"\r\nDòng 2 - Kết quả là: #1030 - Got error -1 from storage engine   Sad\r\n\r\n\r\n---------------------------------------\r\nTôi hiện không thể giải thích cho vấn đề trên, mong mọi người giúp đỡ.'),
('long test'),
('Nguyễn Chí Long');

-- --------------------------------------------------------

--
-- Table structure for table `tinhs`
--

CREATE TABLE IF NOT EXISTS `tinhs` (
  `id` bigint(20) NOT NULL auto_increment,
  `tentinh` varchar(100) character set utf8 default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `tinhs`
--

INSERT INTO `tinhs` (`id`, `tentinh`) VALUES
(1, 'TP Hồ Chí Minh'),
(2, 'Hà Nội'),
(3, 'Đà Nẵng'),
(4, 'Khánh Hòa');

-- --------------------------------------------------------

--
-- Table structure for table `violations`
--

CREATE TABLE IF NOT EXISTS `violations` (
  `id` bigint(20) NOT NULL auto_increment,
  `url` varchar(255) default NULL,
  `account_id` bigint(20) default NULL,
  `status` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `FK_violations_accounts` (`account_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `violations`
--


-- --------------------------------------------------------

--
-- Table structure for table `widgets`
--

CREATE TABLE IF NOT EXISTS `widgets` (
  `id` bigint(20) NOT NULL auto_increment,
  `name` varchar(50) default NULL,
  `content` text,
  `position` varchar(50) default NULL,
  `order` int(11) default NULL,
  `iscomponent` tinyint(1) default NULL,
  `showtitle` tinyint(1) default '1',
  `active` tinyint(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- Dumping data for table `widgets`
--

INSERT INTO `widgets` (`id`, `name`, `content`, `position`, `order`, `iscomponent`, `showtitle`, `active`) VALUES
(1, 'banner', '<img title="banner" src="http://www.jobbid.vn/upload/images/1293468584_banner.jpg" alt="" width="1000" height="178" />', 'banner', 1, 0, 1, 1),
(2, 'Menu', 'components/menu_component/menu.php', 'menu', 1, 1, 1, 1),
(3, 'Tin Mới', 'components/lastnews_component/lastnews_widget.php', 'leftcol', 1, 1, 1, 0),
(4, 'Banner IBM', '<a class="imgbanner" title="IBM" href="http://www.ibm.com" target="_blank"><img title="a" src="http://localhost/mycms/images/upload/1287712085_Older_IBM_Logo_2.png" alt="a" width="240" height="111" /></a>', 'leftcol', 1, 0, 0, 0),
(6, 'Football', '<img style="float: left;" title="d" src="http://vnexpress.net/Files/Subject/3B/A2/11/CD/tung.jpg" alt="aa" width="240" height="245" />', 'rightcol', 1, 0, 1, 0),
(7, 'Footer', '<span style="font-size: small;"><span style="color: #0000ff;"><a href="www.mycms.com">Home</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="http://www.mycms.com">Products</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="http://www.mycms.com">Contact</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; <a href="http://www.mycms.com">Page4&nbsp;</a>&nbsp;&nbsp;&nbsp; &nbsp; &nbsp; <a href="http://www.mycms.com" target="_blank">Page5</a><br /></span><a title="www.mycompany.com" href="http://www.mycompany.com">My CMS</a></span><br /><span style="color: #0000ff; font-size: small;">Design By Nguyễn Ch&iacute; Long</span>', 'footer', 1, 0, 0, 1),
(8, 'Thành Viên', 'components/account_component/account_widget.php', 'rightcol', 1, 1, 1, 1);

--
-- Constraints for dumped tables
--

--
-- Constraints for table `activecodes`
--
ALTER TABLE `activecodes`
  ADD CONSTRAINT `FK_activecodes_accounts` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `duanmarks`
--
ALTER TABLE `duanmarks`
  ADD CONSTRAINT `FK_duanmarks_accounts` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_duanmarks_duans` FOREIGN KEY (`duan_id`) REFERENCES `duans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `duans`
--
ALTER TABLE `duans`
  ADD CONSTRAINT `FK_duans_accounts` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_duans_files` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `duanskills`
--
ALTER TABLE `duanskills`
  ADD CONSTRAINT `FK_duanskills_duan` FOREIGN KEY (`duan_id`) REFERENCES `duans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_duanskills_skills` FOREIGN KEY (`skill_id`) REFERENCES `skills` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `hosothaus`
--
ALTER TABLE `hosothaus`
  ADD CONSTRAINT `FK_bids_duans` FOREIGN KEY (`duan_id`) REFERENCES `duans` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_hosothaus_nhathaus` FOREIGN KEY (`nhathau_id`) REFERENCES `nhathaus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhathaulinhvucs`
--
ALTER TABLE `nhathaulinhvucs`
  ADD CONSTRAINT `FK_nhathaulinhvucs_nhathaus` FOREIGN KEY (`nhathau_id`) REFERENCES `nhathaus` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `nhathaus`
--
ALTER TABLE `nhathaus`
  ADD CONSTRAINT `FK_hosonhathaus_files` FOREIGN KEY (`file_id`) REFERENCES `files` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_nhathaus_accounts` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `resetpasswords`
--
ALTER TABLE `resetpasswords`
  ADD CONSTRAINT `FK_resetpasswords_accounts` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `violations`
--
ALTER TABLE `violations`
  ADD CONSTRAINT `FK_violations_accounts` FOREIGN KEY (`account_id`) REFERENCES `accounts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
