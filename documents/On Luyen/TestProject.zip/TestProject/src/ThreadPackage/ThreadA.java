package ThreadPackage;


public class ThreadA extends Thread {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int i=0;
		while(i<1000000) {
			Test1.one();
			i++;
		}
		
		
		
	}
	
}