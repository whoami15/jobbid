package ThreadPackage;

public class Test1 {
	static int i=0,j=0;
	static synchronized void one() {
		i++;
		j++;
		//System.out.println("i="+i);
	}
	static synchronized void two() {
		System.out.println("i="+i);
		int n=0;
		while(n<10000)
			n++;
		System.out.println("j="+j);
	}
}
