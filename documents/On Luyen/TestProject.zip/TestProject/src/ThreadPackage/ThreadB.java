package ThreadPackage;

public class ThreadB extends Thread {

	@Override
	public void run() {
		// TODO Auto-generated method stub
		int i=0;
		//while(i<1000000) {
			Test1.two();
			i++;
		//}
		
	}
	
}
