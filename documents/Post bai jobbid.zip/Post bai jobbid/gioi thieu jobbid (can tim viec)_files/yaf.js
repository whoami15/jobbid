if(typeof YAF == "undefined") YAF={};
if(typeof YAF.Controls == "undefined") YAF.Controls={};
if(typeof YAF.Controls.ThankYou_class == "undefined") YAF.Controls.ThankYou_class={};
YAF.Controls.ThankYou_class = function() {};
Object.extend(YAF.Controls.ThankYou_class.prototype, Object.extend(new AjaxPro.AjaxClass(), {
	AddThanks: function(msgID) {
		return this.invoke("AddThanks", {"msgID":msgID}, this.AddThanks.getArguments().slice(1));
	},
	RemoveThanks: function(msgID) {
		return this.invoke("RemoveThanks", {"msgID":msgID}, this.RemoveThanks.getArguments().slice(1));
	},
	url: '/ajaxpro/YAF.Controls.ThankYou,YAF.Controls.ashx'
}));
YAF.Controls.ThankYou = new YAF.Controls.ThankYou_class();

