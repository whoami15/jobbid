if(typeof YAF == "undefined") YAF={};
if(typeof YAF.Classes == "undefined") YAF.Classes={};
if(typeof YAF.Classes.Core == "undefined") YAF.Classes.Core={};
if(typeof YAF.Classes.Core.YafFavoriteTopic_class == "undefined") YAF.Classes.Core.YafFavoriteTopic_class={};
YAF.Classes.Core.YafFavoriteTopic_class = function() {};
Object.extend(YAF.Classes.Core.YafFavoriteTopic_class.prototype, Object.extend(new AjaxPro.AjaxClass(), {
	AddFavoriteTopic: function(topicID) {
		return this.invoke("AddFavoriteTopic", {"topicID":topicID}, this.AddFavoriteTopic.getArguments().slice(1));
	},
	RemoveFavoriteTopic: function(topicID) {
		return this.invoke("RemoveFavoriteTopic", {"topicID":topicID}, this.RemoveFavoriteTopic.getArguments().slice(1));
	},
	url: '/ajaxpro/YAF.Classes.Core.YafFavoriteTopic,YAF.Classes.Core.ashx'
}));
YAF.Classes.Core.YafFavoriteTopic = new YAF.Classes.Core.YafFavoriteTopic_class();

